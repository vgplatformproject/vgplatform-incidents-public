# Repro skeleton for incident: dashboard_port_fail
$ErrorActionPreference="Stop"
Set-StrictMode -Version Latest

# TODO: paste minimal steps to reproduce
# Example:
#  $launcher = "D:\VGPlatform\core\ops\pwsh_run.ps1"
#  & $launcher -File "D:\VGPlatform\labs\...\something.ps1" -Args @(...)

Write-Host "REPRO_DONE"
