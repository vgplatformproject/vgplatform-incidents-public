# VG Forensic Audit (audit-only)

- TS: 2026-02-04T23:02:29.6561057+01:00
- VGRoot: `D:\VGPlatform`
- ReportsDir: `D:\VGPlatform\reports`

## Latest forensic bundle

- Dir: D:\VGPlatform\reports\forensic_bundle_20260204_191120
- Zip: D:\VGPlatform\reports\forensic_bundle_20260204_191120\forensic_bundle_20260204_191120.zip

## Extract

- ExtractDir: `D:\VGPlatform\reports\forensic_audit_20260204_230229\extracted`

OK: Extracted.

## ParseCheck (extracted *.ps1)

- Found: 8

OK: all extracted ps1 parsed.

## ScanPidAssignment (repo-wide) - $pid = lines

- FilesScanned: 1018
- Hits: 13

### First 30 hits

- D:\VGPlatform\core\ops\diag\VG_FrontAudit_All_v2.ps1:130  $pid = $null
- D:\VGPlatform\core\ops\diag\VG_PwshSpawnCapture_v1.ps1:148  $pid = [int]$Event.SourceEventArgs.NewEvent.Properties["ProcessID"].Value
- D:\VGPlatform\core\ops\safety\VG_PanicStop.ps1:56  $pid = $h.ProcessId
- D:\VGPlatform\core\ops\VG_AgentPid_Fix.ps1:99  $pid = $cands[0].pid
- D:\VGPlatform\core\ops\VG_ForensicAnalyzer_v3.ps1:127  $pid = $null
- D:\VGPlatform\core\ops\VG_ForensicAnalyzer_v3.ps1:129  $pid = Get-ListenPid $port
- D:\VGPlatform\core\ops\VG_Fronts_HealthReport_v1.ps1:201  $pid = $null
- D:\VGPlatform\reports\forensic_audit_20260204_213548\extracted\vg_all.ps1:250  $pid = Parse-Int $pidTxt
- D:\VGPlatform\reports\forensic_audit_20260204_230229\extracted\vg_all.ps1:250  $pid = Parse-Int $pidTxt
- D:\VGPlatform\reports\forensic_bundle_20260204_185924\staging\core_scripts\core_orchestrator_vg_all.ps1:250  $pid = Parse-Int $pidTxt
- D:\VGPlatform\reports\forensic_bundle_20260204_190420\staging\files\core\orchestrator\vg_all.ps1:250  $pid = Parse-Int $pidTxt
- D:\VGPlatform\reports\forensic_bundle_20260204_191120\staging\vg_all.ps1:250  $pid = Parse-Int $pidTxt
- D:\VGPlatform\tools\queue_tick_taskwrap_safe.ps1:39  $pid = $PID

Guideline: never use $pid as a variable name (conflicts with automatic $PID). Prefer $procId, $dashProcId, $agentProcId.

## Dashboard PID/Port sanity (audit-only)

- dashboard.pid: `D:\VGPlatform\runtime\dashboard.pid` -> `21016`
- dashboard.port: `D:\VGPlatform\runtime\dashboard.port` -> `8501`
- listen pid on 127.0.0.1:8501: 21016
- pidfile alive: True

