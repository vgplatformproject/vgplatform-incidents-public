# VG Health (last)

- ts: 2026-02-04T18:25:31
- overall: OK

## CORE
- dashboard: dash_pid=18368 alive=True port=8501 listen8501_pid=18368 listen8502_pid=
- agent: agent_pid=19608 alive=True heartbeat=YES

## QUEUE
- pending: 0
- working: 0
- done:    43
- failed:  0

## LOCKS
- scanned: D:\VGPlatform\runtime
- locks: 11
- stale: 7

