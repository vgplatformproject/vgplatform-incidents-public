# =========================
# VG_HealthReport_v1.ps1
# =========================
# KONTEKST:
# - CORE/OPS health agregator za VGPlatform
# - Read-only (ne briše, ne restarta). Samo meri in poroča.
#
# VSEBINA:
# - Preveri dashboard/agent PID + port listen
# - Prešteje queue (pending/working/done/failed)
# - Najde stale lock/pid datoteke (PID ne obstaja) -> samo report
# - Zapiše:
#   - D:\VGPlatform\runtime\status.json
#   - D:\VGPlatform\reports\health_last.md
#
# AGENT-PROFIL:
# - Meta/OPS agent lahko iz status.json generira refleksijo, trende in opozorila.
# - CORE orchestrator lahko uporablja status.json kot single source of truth.
#
# OPS NOTE:
# - JSON nikoli ne lepimo v prompt: tu ga generiramo kot object -> ConvertTo-Json.
# - Ne brišemo nič. Samo report + opcijski rename policy bo v ločeni skripti.

[CmdletBinding()]
param(
  [string]$VGRoot = "D:\VGPlatform",
  [switch]$NoMd
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Info($m){ Write-Host ("[INFO] " + $m) -ForegroundColor Cyan }
function Ok($m){ Write-Host ("[OK]   " + $m) -ForegroundColor Green }
function Warn($m){ Write-Host ("[WARN] " + $m) -ForegroundColor Yellow }
function Fail($m){ throw ("[FAIL] " + $m) }

function Need-Dir([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Container)){ Fail "MISSING_DIR=$p" }
}
function Need-Any([string]$p){
  if(!(Test-Path -LiteralPath $p)){ Fail "MISSING_PATH=$p" }
}

function Try-ReadText([string]$p){
  try { return (Get-Content -LiteralPath $p -Raw -EA Stop).Trim() } catch { return $null }
}
function Try-ReadJson([string]$p){
  try {
    $raw = Get-Content -LiteralPath $p -Raw -EA Stop
    return ($raw | ConvertFrom-Json -EA Stop)
  } catch { return $null }
}
function Parse-Int([string]$s){
  if([string]::IsNullOrWhiteSpace($s)){ return $null }
  $n = $null
  if([int]::TryParse($s.Trim(), [ref]$n)){ return $n }
  return $null
}
function Pid-Exists([int]$procId){
  if(!$procId){ return $false }
  try { $null = Get-Process -Id $procId -EA Stop; return $true } catch { return $false }
}
function Port-Listen([int]$port){
  try {
    $c = Get-NetTCPConnection -State Listen -LocalPort $port -EA SilentlyContinue | Select-Object -First 1
    if(!$c){ return $null }
    return [pscustomobject]@{
      port = $port
      pid  = [int]$c.OwningProcess
      local = ($c.LocalAddress + ":" + $c.LocalPort)
    }
  } catch { return $null }
}

function Get-ListenPid($o){
  if($null -eq $o){ return $null }
  try { return $o.pid } catch { return $null }
}

# --- Root checks
Need-Dir $VGRoot

$runtime = Join-Path $VGRoot "runtime"
$reports = Join-Path $VGRoot "reports"
$queue   = Join-Path $VGRoot "queue"
Need-Dir $runtime
New-Item -ItemType Directory -Path $reports -Force | Out-Null

$ts = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
$tsFile = (Get-Date).ToString("yyyyMMdd_HHmmss")

# --- Inputs (optional files)
$dashPidPath  = Join-Path $runtime "dashboard.pid"
$dashPortPath = Join-Path $runtime "dashboard.port"
$agentPidPath = Join-Path $runtime "agent.pid"
$hbPath       = Join-Path $runtime "heartbeat.json"

$dashPidTxt  = Try-ReadText $dashPidPath
$dashPortTxt = Try-ReadText $dashPortPath
$agentPidTxt = Try-ReadText $agentPidPath

$dashPid  = Parse-Int $dashPidTxt
$dashPort = Parse-Int $dashPortTxt
$agentPid = Parse-Int $agentPidTxt

$dashAlive  = $null; if($dashPid){ $dashAlive = Pid-Exists $dashPid }
$agentAlive = $null; if($agentPid){ $agentAlive = Pid-Exists $agentPid }

$listen8501 = Port-Listen 8501
$listen8502 = Port-Listen 8502

# --- Queue counts
$qc = [ordered]@{
  pending = 0
  working = 0
  done    = 0
  failed  = 0
}

foreach($k in @("pending","working","done","failed")){
  $d = Join-Path $queue $k
  if(Test-Path -LiteralPath $d -PathType Container){
    try {
      $qc[$k] = (Get-ChildItem -LiteralPath $d -File -EA Stop | Measure-Object).Count
    } catch {
      $qc[$k] = $null
    }
  } else {
    $qc[$k] = $null
  }
}

# --- Locks scan (bounded to runtime)
$locks = @()
$staleLocks = @()

$lockFiles = @()
try {
  $lockFiles = @(
    Get-ChildItem -LiteralPath $runtime -File -Recurse -EA SilentlyContinue |
      Where-Object { $_.Name -like "*.lock" -or $_.Name -like "*.pid" }
  )
} catch { $lockFiles = @() }

foreach($f in $lockFiles){
  $pidGuess = $null
  $txt = Try-ReadText $f.FullName
  if($txt){
    $pidGuess = Parse-Int ($txt -split "[^\d]+" | Where-Object { $_ } | Select-Object -First 1)
  }
  $alive = $null
  if($pidGuess){ $alive = Pid-Exists $pidGuess }
  $entry = [ordered]@{
    file  = $f.FullName
    pid   = $pidGuess
    alive = $alive
    mtime = (Get-Date $f.LastWriteTime -Format "yyyy-MM-ddTHH:mm:ss")
    size  = $f.Length
  }
  $locks += [pscustomobject]$entry
  if($pidGuess -and ($alive -eq $false)){
    $staleLocks += $f.FullName
  }
}

# --- Heartbeat (optional)
$hb = $null
if(Test-Path -LiteralPath $hbPath -PathType Leaf){
  $hb = Try-ReadJson $hbPath
}

# --- Compose status object
$status = [ordered]@{
  version = "vg_status_v1"
  ts = $ts
  core = [ordered]@{
    dashboard = [ordered]@{
      pid_path  = $dashPidPath
      port_path = $dashPortPath
      pid  = $dashPid
      port = $dashPort
      pid_alive = $dashAlive
      listen_8501 = $listen8501
      listen_8502 = $listen8502
    }
    agent = [ordered]@{
      pid_path = $agentPidPath
      pid = $agentPid
      pid_alive = $agentAlive
      heartbeat_path = $hbPath
      heartbeat = $hb
    }
  }
  queue = [ordered]@{
    root = $queue
    counts = $qc
  }
  locks = [ordered]@{
    scanned_root = $runtime
    count = $locks.Count
    stale_count = $staleLocks.Count
    stale = $staleLocks
    entries = $locks
  }
  notes = @(
    "read-only: no deletes, no restarts",
    "stale locks are reported only"
  )
}

# --- Write JSON
$statusPath = Join-Path $runtime "status.json"
$json = $status | ConvertTo-Json -Depth 12
$json | Set-Content -LiteralPath $statusPath -Encoding UTF8
Ok ("WRITE_OK={0}" -f $statusPath)

# --- Write MD summary
if(-not $NoMd){
  $mdPath = Join-Path $reports "health_last.md"
  $okDash = ($dashAlive -eq $true) -or ($listen8501 -ne $null) -or ($listen8502 -ne $null)
  $okAgent = ($agentAlive -eq $true) -or ($hb -ne $null)
  $overall = if($okDash -and $okAgent){ "OK" } else { "WARN" }

  $dashLine = "dash_pid=$dashPid alive=$dashAlive port=$dashPort listen8501_pid=$(Get-ListenPid $listen8501) listen8502_pid=$(Get-ListenPid $listen8502)"
  $agentLine = "agent_pid=$agentPid alive=$agentAlive heartbeat=" + ($(if($hb){ "YES" } else { "NO" }))

  $md = @"
# VG Health (last)

- ts: $ts
- overall: $overall

## CORE
- dashboard: $dashLine
- agent: $agentLine

## QUEUE
- pending: $($qc.pending)
- working: $($qc.working)
- done:    $($qc.done)
- failed:  $($qc.failed)

## LOCKS
- scanned: $runtime
- locks: $($locks.Count)
- stale: $($staleLocks.Count)

"@

  $md | Set-Content -LiteralPath $mdPath -Encoding UTF8
  Ok ("WRITE_OK={0}" -f $mdPath)
}

Ok "DONE"


