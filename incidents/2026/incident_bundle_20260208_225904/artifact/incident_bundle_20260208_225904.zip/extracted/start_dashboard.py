import streamlit as st

# === VG:REFLECTION_SCORE_WIDGET:BEGIN ===
try:
    from core.dashboard.widgets.reflection_score import render_reflection_score_widget
except Exception:
    try:
        # fallback if running from core/dashboard cwd
        from widgets.reflection_score import render_reflection_score_widget
    except Exception:
        render_reflection_score_widget = None

def _vg_render_reflection_score():
    if render_reflection_score_widget is None:
        return
    try:
        render_reflection_score_widget(r"D:\VGPlatform")
    except Exception:
        pass
# === VG:REFLECTION_SCORE_WIDGET:END ===
st.write('VG DASHBOARD BOOT: ' + __file__)
st.write('Time: ' + __import__('datetime').datetime.now().isoformat())

# --- Early-def: non_blocking_autorefresh (do not move) ---
def non_blocking_autorefresh(seconds: int = 5):
    try:
        ts_key = "_last_refresh_ts"
        now = time.time()
        last = st.session_state.get(ts_key, 0.0)
        if now - last >= max(1, int(seconds)):
            st.session_state[ts_key] = now
            st.experimental_rerun()
    except Exception:
        pass
# ----------------------------------------------------------

from pathlib import Path
MAP_CFG = Path(r"D:\VGPlatform\config\vg_dashboard.json")

import streamlit as st

# === VG:REFLECTION_SCORE_WIDGET:BEGIN ===
try:
    from core.dashboard.widgets.reflection_score import render_reflection_score_widget
except Exception:
    try:
        # fallback if running from core/dashboard cwd
        from widgets.reflection_score import render_reflection_score_widget
    except Exception:
        render_reflection_score_widget = None

def _vg_render_reflection_score():
    if render_reflection_score_widget is None:
        return
    try:
        render_reflection_score_widget(r"D:\VGPlatform")
    except Exception:
        pass
# === VG:REFLECTION_SCORE_WIDGET:END ===
# ------------------------------------
def get_agent_logs():
    try:
        paths = glob.glob(AGENT_LOG_GLOB)
        if not paths:
            return []
        return sorted(paths, key=os.path.getmtime, reverse=True)
    except Exception:
        return []

        return []
def load_mappings(cfg_path: Path):
    try:
        data = json.loads(cfg_path.read_text(encoding="utf-8")); return data.get("mappings", {}), data.get("default")
    except FileNotFoundError: return {}, None
    except Exception as e: st.warning(f"Mapping cfg error: {e}"); return {}, None
def resolve_queue_root():
    maps, default = load_mappings(MAP_CFG); names = sorted(maps.keys()); sel=None
    if names: idx = names.index(default) if default in names else 0; sel = st.sidebar.selectbox("Mapping", names, index=idx, key="mapping_name")
    from pathlib import Path as _P; return _P(maps[sel]["queue"]) if sel else DEFAULT_QUEUE
import re, streamlit as st
# ---- Unique key helper (stable, de-duplicated) ----
import re, streamlit as st
_key_counters = {}
def unique_key(label, scope="main"):
    m = st.session_state.get("mapping_name","default")
    base = f"{scope}_{m}_{label}"
    safe = re.sub(r"[^0-9a-zA-Z_]+","_", base)
    idx = _key_counters.get(safe, 0) + 1
    _key_counters[safe] = idx
    return f"{safe}_{idx}"
# ---- end unique_key ----
def _jsonc_to_json(s:str)->str:
    s = re.sub(r"(?s)/\*.*?\*/", "", s)
    s = re.sub(r"(?m)^\s*//.*$", "", s)
    return s

def load_mappings(path:str):
    try:
        s = read_text_safe(path, "r", encoding="utf-8", errors="ignore")
        j = json.loads(_jsonc_to_json(s))
        return j.get("items", [])
    except Exception:
        return []

def _ps(args:list, timeout=90):
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout)

with st.sidebar:
    st.subheader("VG Control Center")

    # --- mappings.json ---
    maps = load_mappings(MAP_CFG)
    names = [m.get("name","") for m in maps if m.get("name")]
    sel = st.selectbox("Mapping", names, index=0 if names else None)

    c1, c2 = st.columns(2)
    if c1.button("Sync (dry)", use_container_width=True, disabled=not sel, key="smk_btn_sync_dry"):
        res = _ps(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", SYNC_PS, "-Item", sel, "-DryRun"])
        st.code((res.stdout or "") + (res.stderr or ""), language="text")

    if c2.button("SyncQ enqueue", use_container_width=True, disabled=not sel, key=unique_key("SyncQ enqueue", "main")):
        res = _ps(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", ENQ_PS, "-Item", sel, "-DryRun"])
        st.code((res.stdout or "") + (res.stderr or ""), language="text")

    st.divider()
    if st.button("Tick now (1x)", key="smk_btn_tick_once"):
        res = _ps(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", (TICK_PS if TICK_PS else ""), "-Max","50"])
        st.code((res.stdout or "") + (res.stderr or ""), language="text")

    if st.button("Package (ZIP smoke)", key="smk_btn_pkg_smoke"):
        pkg = os.path.join(VG_ROOT, r"tools\packaging\VG_Package_Smoke.ps1")
        res = _ps(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", pkg, "-VerboseList"])
        st.code((res.stdout or "") + (res.stderr or ""), language="text")

    # Queue metrike
def _count(p: str):
    import glob, os
    d = os.path.dirname(p) or '.'
    if not os.path.isdir(d):
        return 0
    try:
        return len(glob.glob(p))
    except Exception:
        return 0
    st.caption("Queue:")
    st.write("• Pending:", _count(os.path.join(QUEUE, "pending", "*.json")))
    st.write("• Working:", _count(os.path.join(QUEUE, "working", "*.json")))
    st.write("• Done   :", _count(os.path.join(QUEUE, "done", "*.json")))
    st.write("• Failed :", _count(os.path.join(QUEUE, "failed", "*.json")))
# [VG SIDEBAR SMOKE END]
PID_FILE        = r"D:\VGPlatform\runtime\agent.pid"
AGENT_LOG_GLOB  = r"D:\VGPlatform\logs\agent\agent_*.log"
REFRESH_SEC     = 2

def read_pid():
    try:
        m = re.search(r"\d+", read_text_safe(PID_FILE,"r",encoding="utf-8",errors="ignore"))
        return int(m.group()) if m else 0
    except Exception:
        return 0

def pid_exists(pid:int)->bool:
    if pid<=0: return False
    try:
        r = subprocess.run(["tasklist","/FI",f"PID eq {pid}"], capture_output=True, text=True, timeout=3)
        return r.returncode==0 and str(pid) in r.stdout
    except Exception:
        return False

def tail(path, n=200):
    try:
        return "".join(open(path,"r",encoding="utf-8",errors="ignore").readlines()[-n:])
    except Exception:
        return ""

st.title("VG Agent — status po PID")
# VG: render reflection score
_vg_render_reflection_score()

pid = read_pid()
running = pid_exists(pid)

c1, c2 = st.columns([3,2])
with c1:
    st.write(f"PID file: {pid or '—'}")
    if running: st.success(f"RUNNING ✅  (PID={pid})")
    else:       st.error("STOPPED / ERROR ❌")
with c2:
    st.write("Auto refresh:", f"{REFRESH_SEC}s")

st.subheader("Agent log")
logs = get_agent_logs()
if logs:
    last = logs[-1]
    st.caption(last)
    st.code(tail(last, 400), language="text")
else:
    st.info("Ni agent log datotek.")

non_blocking_autorefresh(REFRESH_SEC)
# st.rerun()  # disabled by VG fix
# ====================== VG Dashboard – Jobs ======================
import os, glob, json, time, subprocess, uuid

QUEUE_DIR = r"D:\VGPlatform\queue"
ENQ_PS    = r"D:\VGPlatform\tools\queue\enqueue.ps1"
TICK_PS   = r"D:\VGPlatform\tools\queue_tick.ps1"

def _count(pat: str) -> int:
    return len(glob.glob(pat))

def _list_latest(folder: str, n: int = 8):
    files = glob.glob(os.path.join(folder, "*.json"))
    files.sort(key=os.path.getmtime, reverse=True)
    return files[:n]

st.divider()
st.header("Jobs")

# --- Summary metrika ---
c1, c2, c3, c4 = st.columns(4)
c1.metric("Pending", _count(os.path.join(QUEUE_DIR, "pending", "*.json")))
c2.metric("Working", _count(os.path.join(QUEUE_DIR, "working", "*.json")))
c3.metric("Done",    _count(os.path.join(QUEUE_DIR, "done", "*.json")))
c4.metric("Failed",  _count(os.path.join(QUEUE_DIR, "failed", "*.json")))

# --- Enqueue form ---
with st.expander("Dodaj job (enqueue)", expanded=True):
    with st.form("enqueue_form"):
        jtype = st.selectbox("Vrsta opravila", ["echo", "httpget", "copy"])

        payload = {}
        if jtype == "echo":
            payload["message"] = st.text_input("Sporočilo", "Pozdrav iz dashboarda")
        elif jtype == "httpget":
            payload["url"] = st.text_input("URL", "https://example.org")
            payload["save_to"] = st.text_input("Shrani kot", r"D:\VGPlatform\runtime\download.html")
        elif jtype == "copy":
            payload["src"] = st.text_input("Izvor", r"C:\Windows\win.ini")
            payload["dst"] = st.text_input("Cilj",  r"D:\VGPlatform\runtime\win_copy.ini")
            payload["overwrite"] = st.checkbox("Prepiši, če obstaja", True)

        submitted = st.form_submit_button("ENQUEUE")
        if submitted:
            try:
                pj = json.dumps(payload, ensure_ascii=False)
                cmd = ["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", ENQ_PS, "-Type", jtype, "-PayloadJson", pj]
                res = subprocess.run(cmd, capture_output=True, text=True)
                st.code((res.stdout or "") + (res.stderr or ""), language="text")
                st.success("Job enqueued.")
                time.sleep(1); st.rerun()
            except Exception as e:
                st.error(f"Enqueue napaka: {e}")

# --- Ročni “tick now” ---
st.subheader("Procesiraj zdaj (1x tick)")
if st.button("Tick now", key=unique_key("Tick now", "main")):
    try:
        res = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-File", (TICK_PS if TICK_PS else ""), "-Max","50"], capture_output=True, text=True)
        st.code((res.stdout or "") + (res.stderr or ""), language="text")
        time.sleep(1); st.rerun()
    except Exception as e:
        st.error(f"Tick napaka: {e}")

# --- Pregled zadnjih datotek ---
st.subheader("Zadnji jobi")
tabs = st.tabs(["Pending", "Working", "Done", "Failed"])
folders = ["pending", "working", "done", "failed"]
for i, tab in enumerate(tabs):
    with tab:
        folder = os.path.join(QUEUE_DIR, folders[i])
        items = _list_latest(folder, 8)
        if not items:
            st.info("Ni datotek.")
        else:
            for p in items:
                st.caption(p)
                try:
                    st.code(read_text_safe(p, 4000), language="json")
                except Exception:
                    st.code("(ni mogoče prebrati)", language="text")

# [VG CONTROL START]
try:
    import os, subprocess
    VG_ROOT = os.environ.get("VG_ROOT", r"D:\VGPlatform")

    def _ps_run(rel_path, *ps_args, timeout=45):
        path = os.path.join(VG_ROOT, *rel_path.split("\\"))
        if not os.path.exists(path):
            st.error(f"Script not found: {path}")
            return 2, "", "not found"
        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path] + list(ps_args)
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            return r.returncode, r.stdout.strip(), r.stderr.strip()
        except subprocess.TimeoutExpired as e:
            return 124, (e.stdout or ""), f"Timeout: {e}"
        except Exception as e:
            return 1, "", f"Run error: {e}"

    with st.sidebar:
        st.subheader("VG Control Center")
        if st.button("Quick Status", key=unique_key("Quick Status","main")):
            code,out,err = _ps_run(r"tools\health\VG_Quick_Status.ps1")
            st.code(out or err or "(no output)")
        if st.button("Task Audit", key=unique_key("Task Audit","main")):
            code,out,err = _ps_run(r"tools\health\VG_Task_Audit.ps1")
            st.code(out or err or "(no output)")
        if st.button("Preflight (-Fix)", key=unique_key("Preflight (-Fix)","main")):
            code,out,err = _ps_run(r"core\orchestrator\preflight.ps1","-Fix")
            st.code(out or err or "(no output)")
        if st.button("LogsCap (Dry Run)", key=unique_key("LogsCap (Dry Run)","main")):
            code,out,err = _ps_run(r"tools\logs\VG_LogsCap.ps1","-DryRun")
            st.code(out or err or "(no output)")
        st.caption("VGPlatform @ " + VG_ROOT)
except Exception as e:
    try:

        st.warning("Control Center init failed: {}".format(e))
    except Exception:
        pass
# [VG CONTROL END]

# [VG SYNC MAP UI START]
import json, os, subprocess, glob, time, streamlit as st

import glob



import os
import json
import re
import uuid

import time
MAPPINGS_PATH = r"D:\VGPlatform\config\sync\mappings.json"
QROOT         = r"D:\VGPlatform\queue"
RETRY_PS      = r"D:\VGPlatform\tools\queue\VG_Retry_LastFailed.ps1"
RETAIN_PS     = r"D:\VGPlatform\tools\queue\VG_Retention.ps1"

RET_DONE_THRESHOLD = 2000
RET_DONE_KEEP      = 500

def _load_maps():
    try:
        raw = read_text_safe(MAPPINGS_PATH, "r", encoding="utf-8").lstrip("\ufeff")
        import re, json as _json
        try: data = _json.loads(raw)
        except Exception: data = _json.loads(re.sub(r",(\s*[\]\}])", r"\1", raw))
        if isinstance(data, dict) and "items" in data: return data["items"]
        return data if isinstance(data, list) else []
    except Exception:
        return []

_maps  = _load_maps()
_names = [m.get("name","") for m in _maps if m.get("name")]

def _cnt(folder):
    try: return len(glob.glob(os.path.join(QROOT, folder, "*.json")))
    except Exception: return 0

with st.sidebar:
    st.subheader("VG Control Center")

    sel = st.selectbox("Mapping", _names, index=0 if _names else None, placeholder="Izberi mapping")
    sel_map = next((m for m in _maps if m.get("name")==sel), None)

    # --- Sync kontrole ---
    c1, c2 = st.columns(2)
    if c1.button("Sync (dry)", use_container_width=True, disabled=not sel, key="map_btn_sync_dry"):
        r = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                            "-File", r"D:\VGPlatform\tools\sync\VG_Sync_RunOne.ps1",
                            "-Item", sel, "-DryRun"], capture_output=True, text=True)
        st.code((r.stdout or "")+(r.stderr or ""), "text")

    if c2.button("SyncQ enqueue", use_container_width=True, disabled=not sel, key=unique_key("SyncQ enqueue", "main")):
        r = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                            "-File", r"D:\VGPlatform\tools\sync\VG_Enqueue_Sync.ps1",
                            "-Item", sel], capture_output=True, text=True)
        st.code((r.stdout or "")+(r.stderr or ""), "text")

    if st.button("Sync apply now (enqueue + tick)", use_container_width=True, disabled=not sel, key="btn_apply_now"):
        r1 = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                             "-File", r"D:\VGPlatform\tools\sync\VG_Enqueue_Sync.ps1",
                             "-Item", sel], capture_output=True, text=True)
        st.code((r1.stdout or "")+(r1.stderr or ""), "text")
        r2 = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                             "-File", r"D:\VGPlatform\tools\queue_tick.ps1", "-Max", "50"],
                             capture_output=True, text=True)
        st.code((r2.stdout or "")+(r2.stderr or ""), "text")

    # --- Open SRC/DST ---
    c3, c4 = st.columns(2)
    if c3.button("Open SRC", use_container_width=True, disabled=not (sel_map and sel_map.get("src")), key="btn_open_src"):
        try: subprocess.run(["explorer", sel_map.get("src","")])
        except Exception as e: st.error(str(e))
    if c4.button("Open DST", use_container_width=True, disabled=not (sel_map and sel_map.get("dst")), key="btn_open_dst"):
        try: subprocess.run(["explorer", sel_map.get("dst","")])
        except Exception as e: st.error(str(e))

    st.divider()
    st.caption("Queue:")
    st.write(f"• Pending: **{_cnt('pending')}**")
    st.write(f"• Working: **{_cnt('working')}**")
    st.write(f"• Done: **{_cnt('done')}**")
    st.write(f"• Failed: **{_cnt('failed')}**")

    if st.button("Tick now (1x)", use_container_width=True, key="map_btn_tick_once"):
        r = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                            "-File", r"D:\VGPlatform\tools\queue_tick.ps1","-Max","50"],
                           capture_output=True, text=True)
        st.code((r.stdout or "")+(r.stderr or ""), "text")

    c5, c6 = st.columns(2)
    if c5.button("Retry ALL Failed", use_container_width=True, key=unique_key("Retry ALL Failed", "main")):
        r = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                            "-File", RETRY_PS], capture_output=True, text=True)
        st.code((r.stdout or "")+(r.stderr or ""), "text")
    if c6.button("Retention sweep", use_container_width=True, key=unique_key("Retention sweep", "main")):
        r = subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
                            "-File", RETAIN_PS, "-Folder", "done",
                            "-Threshold", str(RET_DONE_THRESHOLD), "-KeepLast", str(RET_DONE_KEEP)],
                           capture_output=True, text=True)
        st.code((r.stdout or "")+(r.stderr or ""), "text")

    try:
        rr = subprocess.run(["powershell","-NoProfile","-Command",
                             "Get-ScheduledTaskInfo -TaskName 'VGQueueTick' | Select -Expand NextRunTime"],
                            capture_output=True, text=True, timeout=5)
        nxt = (rr.stdout or "").strip()
        if nxt: st.caption("VGQueueTick NextRun: " + nxt)
    except Exception:
        pass
# [VG SYNC MAP UI END]
# [VG SIDEBAR FORCE CSS]
st.markdown("""

""", unsafe_allow_html=True)
# [VG SIDEBAR FORCE CSS END]

# [VG SIDEBAR FORCE START]
st.markdown("""
<style>
  [data-testid="stSidebar"] { display:block !important; min-width:300px; }
  [data-testid="stSidebarCollapsedControl"] { visibility:visible !important; opacity:1 !important; }
</style>
""", unsafe_allow_html=True)
# [VG SIDEBAR FORCE END]



























# ---- Agent logs (safe defaults) ----
AGENT_LOG_GLOB = r"D:\VGPlatform\logs\agent\agent_*.log"
def get_agent_logs():
    try:
        paths = glob.glob(AGENT_LOG_GLOB)
        if not paths:
            return []
        return sorted(paths, key=os.path.getmtime, reverse=True)
    except Exception:
        return []
# ------------------------------------



# --- Non-blocking autorefresh for Streamlit ---
def non_blocking_autorefresh(seconds: int = 5):
    try:
        ts_key = "_last_refresh_ts"
        now = time.time()
        last = st.session_state.get(ts_key, 0.0)
        if now - last >= max(1, int(seconds)):
            st.session_state[ts_key] = now
            st.experimental_rerun()
    except Exception:
        pass
# ----------------------------------------------








# --- Packaging smoke (optional) ---
try:
    import os, streamlit as st
    pkg = os.path.join(VG_ROOT, r"tools\\packaging\\VG_Package_Smoke.ps1")
    if os.path.exists(pkg):
        st.caption(f"Packaging smoke: {pkg}")
    else:
        st.caption("Packaging smoke ni na voljo na tem sistemu.")
except Exception as e:
    # non-fatal
    st.caption(f"Packaging smoke error: {e}")



