[CmdletBinding()]
param(
  [string]$Root = "D:\VGPlatform",
  [Parameter(Mandatory=$true)][string]$Json,
  [string]$IncomingRel = "queue\incoming",
  [switch]$Normalize,
  [switch]$Report,
  [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference="Stop"

function Ts(){ [DateTimeOffset]::Now.ToString("o") }
function Fail($m){ throw $m }

# --- env ---
$validate = Join-Path $Root "core\queue\validate_job.ps1"
if(-not (Test-Path -LiteralPath $validate)){ Fail "Missing validator: $validate" }

$inDir = Join-Path $Root $IncomingRel
New-Item -ItemType Directory -Force -Path $inDir | Out-Null

$repDir = Join-Path $Root "vault\reports"
New-Item -ItemType Directory -Force -Path $repDir | Out-Null

# --- stage json (never paste raw objects directly here; caller passes string) ---
$tmpJson = Join-Path $env:TEMP ("vg_job_{0}.json" -f ([guid]::NewGuid().ToString("N")))
$Json | Set-Content -LiteralPath $tmpJson -Encoding UTF8

# --- validate + optional normalize (in temp file) ---
try {
  & pwsh -NoProfile -ExecutionPolicy Bypass -File $validate -Path $tmpJson -Normalize:$Normalize -WriteBack:$Normalize | Out-Null
} catch {
  Remove-Item -LiteralPath $tmpJson -Force -EA SilentlyContinue
  Fail ("Enqueue refused: {0}" -f $_.Exception.Message)
}

# --- final name ---
$stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
$fn = "job_{0}_{1}.json" -f $stamp, ([guid]::NewGuid().ToString("N").Substring(0,8))
$dst = Join-Path $inDir $fn

# atomic-ish: move temp -> incoming
if($WhatIf){
  Write-Host ("WHATIF ENQUEUE -> {0}" -f $dst)
} else {
  Move-Item -LiteralPath $tmpJson -Destination $dst -Force
  Write-Host ("ENQUEUED {0}" -f $dst)
}

# report (optional)
if($Report){
  $r = [ordered]@{
    ts = Ts
    root = $Root
    incoming = $inDir
    path = $dst
    normalize = [bool]$Normalize
    whatIf = [bool]$WhatIf
  }
  $out = Join-Path $repDir ("enqueue_{0}.json" -f $stamp)
  ($r | ConvertTo-Json -Depth 10) | Set-Content -LiteralPath $out -Encoding UTF8
  Write-Host ("REPORT {0}" -f $out)
}
