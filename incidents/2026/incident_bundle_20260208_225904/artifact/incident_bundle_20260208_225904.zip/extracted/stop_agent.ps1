$ErrorActionPreference='SilentlyContinue'
$PidFile = "D:\VGPlatform\runtime\agent.pid"
$Match   = [Regex]::Escape("agent_host.ps1")

$stopped=$false
if (Test-Path $PidFile) {
  $VgPid = 0; try { $VgPid = [int](([IO.File]::ReadAllText($PidFile) -replace '[^\d]','')) } catch {}
  if ($VgPid -gt 0) { try { Stop-Process -Id $VgPid -Force -ErrorAction Stop; $stopped=$true } catch {} }
}
if (-not $stopped) {
  Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $Match } |
    ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
}
Remove-Item $PidFile -Force -ErrorAction SilentlyContinue | Out-Null
Write-Host 'Agent stopped (if running).'



# PID_CLEAR_BEGIN
try{
  $pidPath = Join-Path $Root "runtime\agent.pid"
  if(Test-Path -LiteralPath $pidPath){
    Clear-Content -LiteralPath $pidPath -Force
    Write-Host ("PID_CLEAR_OK={0}" -f $pidPath)
  }
} catch {
  Write-Host ("PID_CLEAR_FAIL={0}" -f $_.Exception.Message)
}
# PID_CLEAR_END
