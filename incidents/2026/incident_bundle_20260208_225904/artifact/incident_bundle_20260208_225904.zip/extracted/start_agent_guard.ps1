[CmdletBinding()]
param(
  [string]$Root = "D:\VGPlatform"
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function _TS(){ (Get-Date).ToString("s") }
function Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Warn($m){ Write-Host "[WARN] $m" -ForegroundColor Yellow }
function Ok($m){ Write-Host "[OK]   $m" -ForegroundColor Green }

# --- task log (append, never delete)
$logDir = Join-Path $Root "logs\agent"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$log = Join-Path $logDir "start_agent_guard.log"
function Log($m){
  try{ ("[{0}] {1}" -f (_TS),$m) | Add-Content -LiteralPath $log -Encoding UTF8 } catch {}
}

Log ("BEGIN user={0} root={1}" -f $env:USERNAME,$Root)

# --- Guard lock (own lock name; do NOT share with 1-min watchdog)
$lockDir = Join-Path $Root "runtime\locks"
New-Item -ItemType Directory -Path $lockDir -Force | Out-Null
$lock = Join-Path $lockDir "VGAgentBoot.lock"
$now  = Get-Date

try{
  if(Test-Path -LiteralPath $lock -PathType Leaf){
    $ageSec = 999999
    try{ $ageSec = [int](($now - (Get-Item -LiteralPath $lock -EA SilentlyContinue).LastWriteTime).TotalSeconds) } catch {}
    if($ageSec -lt 90){
      Warn ("LOCK_ACTIVE age_sec={0} -> exit" -f $ageSec)
      Log ("EXIT lock_active age_sec={0}" -f $ageSec)
      exit 0
    } else {
      Warn ("LOCK_STALE age_sec={0} -> remove" -f $ageSec)
      Log ("LOCK stale -> remove age_sec={0}" -f $ageSec)
      Remove-Item -LiteralPath $lock -Force -EA SilentlyContinue
    }
  }
  "lock" | Set-Content -LiteralPath $lock -Encoding ASCII
} catch {
  Warn ("LOCK_FAILED {0}" -f $_.Exception.Message)
  Log ("LOCK_FAILED {0}" -f $_.Exception.Message)
}

# --- Paths
$runDir = Join-Path $Root "runtime"
New-Item -ItemType Directory -Path $runDir -Force | Out-Null
$agentPidPath = Join-Path $runDir "agent.pid"
$startAgent = Join-Path $Root "core\orchestrator\start_agent.ps1"

function Read-IntPid([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Leaf)){ return $null }
  $t = (Get-Content -LiteralPath $p -Raw -EA SilentlyContinue).Trim()
  $n = 0
  if([int]::TryParse($t,[ref]$n) -and $n -gt 0){ return $n }
  return $null
}

function Pid-Running([int]$id){
  if(-not $id){ return $false }
  return [bool](Get-Process -Id $id -EA SilentlyContinue)
}

$existing = Read-IntPid $agentPidPath
if($existing -and (Pid-Running $existing)){
  Ok ("AGENT_ALREADY_RUNNING pid={0}" -f $existing)
  Log ("DONE already_running pid={0}" -f $existing)
  exit 0
}

if(!(Test-Path -LiteralPath $startAgent -PathType Leaf)){
  Warn ("START_AGENT_MISSING={0}" -f $startAgent)
  Log ("EXIT start_agent_missing path={0}" -f $startAgent)
  exit 1
}

Info ("STARTING_AGENT via {0}" -f $startAgent)
Log ("START start_agent.ps1 path={0}" -f $startAgent)

$pwsh = (Get-Command pwsh -EA SilentlyContinue).Source
if([string]::IsNullOrWhiteSpace($pwsh)){ $pwsh = "C:\Program Files\PowerShell\7\pwsh.exe" }

try{
  $child = Start-Process -FilePath $pwsh -ArgumentList @(
    "-NoProfile",
    "-ExecutionPolicy","Bypass",
    "-File", $startAgent
  ) -WorkingDirectory (Split-Path -Parent $startAgent) -PassThru -WindowStyle Hidden

  if($child -and $child.Id){
    $child.Id.ToString() | Set-Content -LiteralPath $agentPidPath -Encoding ASCII
    Ok ("WROTE agent.pid pid={0}" -f $child.Id)
    Log ("WROTE agent.pid pid={0}" -f $child.Id)
    exit 0
  } else {
    Warn "START_PROCESS_NO_PID"
    Log "EXIT start_process_no_pid"
    exit 1
  }
} catch {
  Warn ("START_PROCESS_FAIL {0}" -f $_.Exception.Message)
  Log ("EXIT start_process_fail {0}" -f $_.Exception.Message)
  exit 1
}
