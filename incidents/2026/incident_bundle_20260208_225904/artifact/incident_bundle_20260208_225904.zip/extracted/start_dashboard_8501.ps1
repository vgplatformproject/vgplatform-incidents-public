param(
  [int]$Port = 8501,
  [string]$Root = "D:\VGPlatform"
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Append-File([string]$path,[string]$line){
  try{ Add-Content -LiteralPath $path -Value ($line + "`r`n") -Encoding UTF8 } catch {}
}

function Resolve-RealPython {
  $cands = New-Object System.Collections.Generic.List[string]

  try{
    if(Get-Command py -EA SilentlyContinue){
      try{
        $p = (& py -3 -c "import sys; print(sys.executable)" 2>$null | Out-String).Trim()
        if($p){ $cands.Add($p) }
      } catch {}
    }
  } catch {}

  try{
    & where.exe python 2>$null | ForEach-Object { if($_){ $cands.Add($_) } }
  } catch {}

  $u = @($cands | Select-Object -Unique)
  $u = @($u | Where-Object { $_ -and ($_ -notmatch "\\WindowsApps\\python\.exe$") })
  if($u.Length -gt 0){ return $u[0] }
  return $null
}

if(!(Test-Path -LiteralPath $Root -PathType Container)){ exit 10 }

$AppPy    = Join-Path $Root "core\dashboard\start_dashboard.py"
$LogDir   = Join-Path $Root "logs\dashboard"
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

$ts = Get-Date -Format "yyyyMMdd_HHmmss"

# IMPORTANT: keep our launcher log separate from streamlit stdout/stderr (stdout redirect can truncate files)
$LaunchLog = Join-Path $LogDir ("dashboard_launch_{0}_p{1}.log" -f $ts,$Port)
$OutLog    = Join-Path $LogDir ("dashboard_task_{0}_p{1}.out.log" -f $ts,$Port)
$ErrLog    = Join-Path $LogDir ("dashboard_task_{0}_p{1}.err.log" -f $ts,$Port)

Append-File $LaunchLog ("ts={0}" -f $ts)
Append-File $LaunchLog ("root={0}" -f $Root)
Append-File $LaunchLog ("app={0}" -f $AppPy)

if(!(Test-Path -LiteralPath $AppPy -PathType Leaf)){
  Append-File $LaunchLog ("APP_MISSING={0}" -f $AppPy)
  exit 10
}

$Python = Resolve-RealPython
if(-not $Python){
  Append-File $LaunchLog "PYTHON_MISSING_REAL (WindowsApps stub is not acceptable)."
  exit 10
}

Append-File $LaunchLog ("python={0}" -f $Python)
try { Append-File $LaunchLog ("python --version => {0}" -f ((& $Python --version 2>&1 | Out-String).Trim())) } catch {}

# streamlit check
try{
  $sl = (& $Python -m streamlit --version 2>&1 | Out-String).Trim()
  Append-File $LaunchLog ("streamlit={0}" -f $sl)
  if($sl -notmatch 'Streamlit'){
    Append-File $LaunchLog ("STREAMLIT_MISSING for python={0}" -f $Python)
    exit 11
  }
} catch {
  Append-File $LaunchLog ("STREAMLIT_CHECK_FAILED: " + $_.Exception.Message)
  exit 11
}

# --- ALREADY_LISTENING_GUARD
try{
  $c = Get-NetTCPConnection -State Listen -LocalPort $Port -EA SilentlyContinue | Select-Object -First 1
  if($c){
    Append-File $LaunchLog ("ALREADY_LISTENING 127.0.0.1:{0} pid={1}" -f $Port,$c.OwningProcess)
    exit 0
  }
} catch {}
# --- /ALREADY_LISTENING_GUARD

# start streamlit
$wd = Split-Path -Parent $AppPy
$args = @(
  "-m","streamlit","run",$AppPy,
  "--server.address","127.0.0.1",
  "--server.port",$Port.ToString(),
  "--server.headless","true"
)

Append-File $LaunchLog ("START: {0} {1}" -f $Python,($args -join " "))

try{
  $p = Start-Process -FilePath $Python -ArgumentList $args -WorkingDirectory $wd `
    -RedirectStandardOutput $OutLog -RedirectStandardError $ErrLog -PassThru -WindowStyle Hidden
  Append-File $LaunchLog ("PID={0}" -f $p.Id)
} catch {
  Append-File $LaunchLog ("START_PROCESS_FAILED: " + $_.Exception.Message)
  exit 12
}

# wait for port
$ok=$false
for($i=0;$i -lt 25;$i++){
  Start-Sleep -Seconds 1
  try{
    $c = Get-NetTCPConnection -State Listen -LocalPort $Port -EA SilentlyContinue | Select-Object -First 1
    if($c){ $ok=$true; break }
  } catch {}
}

if(-not $ok){
  Append-File $LaunchLog ("PORT_NOT_LISTENING: port={0} pid={1}" -f $Port,$p.Id)
  exit 2
}

Append-File $LaunchLog ("OK_LISTENING 127.0.0.1:{0} pid={1}" -f $Port,$p.Id)
exit 0
