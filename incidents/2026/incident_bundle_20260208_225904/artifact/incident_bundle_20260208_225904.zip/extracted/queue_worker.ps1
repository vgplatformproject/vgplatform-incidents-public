<#
KONTEKST
- Stabilen wrapper/compat layer za VG queue worker.
- Namen: forwardanje na canonical worker: core\queue\queue_worker_vgcore.ps1
- Ključ: VGCore parametre detektiramo prek AST (Parser), ne prek Get-Command.

VSEBINA
- Validira okolje
- AST prebere parametre VGCore
- Forwarda samo tiste parametre, ki obstajajo
- Če user zahteva -Once, a VGCore nima Once parametra: prisili MaxIdleSec (bounded run)
- Zažene VGCore in vrne isti exitcode
- Best-effort napiše runtime\queue_status.json (bounded counts)

AGENT-PROFIL
- Varna "front door" točka za scheduled tasks / orchestrator.
#>

[CmdletBinding()]
param(
  [Parameter()][ValidateNotNullOrEmpty()][string]$Root = "D:\VGPlatform",

  # runtime tuning (forward ONLY if VGCore supports)
  [Parameter()][ValidateRange(50,60000)][int]$TickMs = 1000,
  [Parameter()][ValidateRange(0,86400)][int]$MaxIdleSec = 0,

  # optional (forward ONLY if VGCore supports)
  [Parameter()][int]$StatusEverySec = 0,

  # wrapper-only hints (forward ONLY if VGCore supports)
  [Parameter()][int]$MaxRuntimeMin = 0,
  [Parameter()][switch]$Once
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function _Ok([string]$m){ "OK: $m" | Write-Host }
function _Warn([string]$m){ "WARN: $m" | Write-Host }

function _VG_GetScriptParamNames([string]$path){
  $tokens=$null; $errs=$null
  $ast = [System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errs)
  if($errs -and $errs.Count -gt 0){
    _Warn ("VGCORE_PARSE_ERR_COUNT=" + $errs.Count)
    foreach($e in ($errs | Select-Object -First 5)){
      _Warn ("VGCORE_PARSE_ERR: " + $e.Message)
    }
    return @()
  }
  if(-not $ast.ParamBlock){ return @() }
  $n=@()
  foreach($p in $ast.ParamBlock.Parameters){
    if($p -and $p.Name -and $p.Name.VariablePath){
      $n += $p.Name.VariablePath.UserPath
    }
  }
  @($n | Where-Object { $_ } | Select-Object -Unique)
}

# resolve + validate
$Root = (Resolve-Path -LiteralPath $Root).Path
$vgc  = Join-Path $Root "core\queue\queue_worker_vgcore.ps1"
if(!(Test-Path -LiteralPath $vgc -PathType Leaf)){ throw "MISSING_VGCORE=$vgc" }

$pwshCmd = Get-Command pwsh -ErrorAction SilentlyContinue
if(-not $pwshCmd){ throw "PWSH_NOT_FOUND" }

# AST supported params
$supported = @(_VG_GetScriptParamNames $vgc)
function _HasParam([string]$n){ return ($supported -contains $n) }
_Ok ("VGCORE_AST_PARAMS=" + (($supported -join ",")))

# If user requested Once but VGCore has no Once param, force bounded idle exit via MaxIdleSec
if($Once -and (-not (_HasParam "Once"))){
  if($MaxIdleSec -le 0){
    $MaxIdleSec = 5
    _Warn "VGCORE_NO_ONCE_PARAM -> forcing MaxIdleSec=5 to make run bounded"
  } else {
    _Warn "VGCORE_NO_ONCE_PARAM -> relying on MaxIdleSec"
  }
}

# build arglist to run VGCore
$args = New-Object System.Collections.Generic.List[string]
$args.Add("-NoProfile")
$args.Add("-ExecutionPolicy"); $args.Add("Bypass")
$args.Add("-File"); $args.Add($vgc)

# forward only supported params (explicit parentheses for parser stability)
if(_HasParam "Root"){
  $args.Add("-Root"); $args.Add($Root)
} else {
  _Warn "VGCORE_NO_ROOT_PARAM (skipping -Root)"
}

if( ($TickMs -gt 0) -and (_HasParam "TickMs") ){
  $args.Add("-TickMs"); $args.Add([string]$TickMs)
}

if( ($MaxIdleSec -ge 0) -and (_HasParam "MaxIdleSec") ){
  $args.Add("-MaxIdleSec"); $args.Add([string]$MaxIdleSec)
}

if( ($StatusEverySec -gt 0) -and (_HasParam "StatusEverySec") ){
  $args.Add("-StatusEverySec"); $args.Add([string]$StatusEverySec)
}

# optional (only if exists)
if( ($MaxRuntimeMin -gt 0) -and (_HasParam "MaxRuntimeMin") ){
  $args.Add("-MaxRuntimeMin"); $args.Add([string]$MaxRuntimeMin)
}

if( $Once -and (_HasParam "Once") ){
  $args.Add("-Once")
}

_Ok ("WRAP_FORWARD_TO=" + $vgc)
_Ok ("WRAP_ARGS=" + ($args -join " "))

$ec = 0
try{
  & $pwshCmd.Source @args
  $ec = $LASTEXITCODE
} finally {
  # BEGIN VG_QUEUE_STATUS_V1 (best-effort, never breaks worker)
  try{
    function _VG_WriteJsonAtomic([string]$p, $obj){
      $dir = Split-Path -Parent $p
      if(!(Test-Path -LiteralPath $dir -PathType Container)){
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
      }
      $tmp  = $p + ".tmp"
      $json = ($obj | ConvertTo-Json -Depth 10)
      Set-Content -LiteralPath $tmp -Value $json -Encoding UTF8 -NoNewline -Force
      Move-Item -LiteralPath $tmp -Destination $p -Force
    }

    $runtime = Join-Path $Root "runtime"
    if(!(Test-Path -LiteralPath $runtime -PathType Container)){
      New-Item -ItemType Directory -Path $runtime -Force | Out-Null
    }

    $q = Join-Path $Root "queue"
    $pending = Join-Path $q "pending"
    $working = Join-Path $q "working"
    $done    = Join-Path $q "done"
    $failed  = Join-Path $q "failed"

    $cntPending = (Test-Path -LiteralPath $pending -PathType Container) ? @((Get-ChildItem -LiteralPath $pending -File -EA SilentlyContinue)).Count : 0
    $cntWorking = (Test-Path -LiteralPath $working -PathType Container) ? @((Get-ChildItem -LiteralPath $working -File -EA SilentlyContinue)).Count : 0
    $cntDone    = (Test-Path -LiteralPath $done -PathType Container)    ? @((Get-ChildItem -LiteralPath $done -File -EA SilentlyContinue)).Count : 0
    $cntFailed  = (Test-Path -LiteralPath $failed -PathType Container)  ? @((Get-ChildItem -LiteralPath $failed -File -EA SilentlyContinue)).Count : 0

    $statusPath = Join-Path $runtime "queue_status.json"
    $obj = [ordered]@{
      ts   = (Get-Date).ToString("o")
      host = $env:COMPUTERNAME
      pid  = $PID
      exitcode = $ec
      counts = [ordered]@{
        pending = $cntPending
        working = $cntWorking
        done    = $cntDone
        failed  = $cntFailed
      }
    }
    _VG_WriteJsonAtomic $statusPath $obj
  } catch { }
  # END VG_QUEUE_STATUS_V1
}

exit $ec
