<#
KONTEKST
- Modul: core/orchestrator/start_agent.ps1
- Namen: zagon watchdog agenta (watchdog_agentB_logger.ps1) na varen, idempotenten način.
- Pravilo: SINGLETON/Another instance = OK (watchdog že teče), nikoli FAIL.

VSEBINA
- Preveri okolje (Root, pwsh, watchdog script).
- Če watchdog že teče: zapiše PID v runtime\agent.pid in konča OK.
- Če watchdog ne teče: ga zažene, počaka, preveri alive.
- Če proces takoj umre, prebere out/err tail in če zazna SINGLETON -> poišče obstoječ proces in konča OK.
- V vseh drugih primerih -> FAIL.

AGENT-PROFIL
- Primerno za ročni zagon in scheduled task; brez interaktivnosti; robusten logging.
#>

[CmdletBinding()]
param(
  [string]$Root = "D:\VGPlatform"
)
# BEGIN_VG_GUARD_PRECHECK_V1
# OPS: Guard/Panic precheck to prevent runaway starts
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

$root2 = [string]$Root
if([string]::IsNullOrWhiteSpace($root2)){ $root2 = "D:\VGPlatform" }

# NOTE: align with VG_SystemGuard_v1.ps1 panic path (if/when implemented there)
# PANIC lock check (support legacy + guard path)
$panicLegacy = Join-Path $root2 "runtime\panic.lock.json"
$panicGuard  = Join-Path $root2 "runtime\vg_panic_lock.json"
foreach($pl in @($panicGuard,$panicLegacy)){
  if(Test-Path -LiteralPath $pl -PathType Leaf){
    Write-Host ("WARN: PANIC_LOCK_PRESENT={0}" -f $pl)
    try{ Write-Host (Get-Content -LiteralPath $pl -Raw -Encoding UTF8) } catch {}
    throw "PANIC_LOCK_ACTIVE"
  }
}

$guard = Join-Path $root2 "core\ops\guard\VG_SystemGuard_v1.ps1"
if(Test-Path -LiteralPath $guard -PathType Leaf){
  try{
    & $guard -Root $root2 -Mode Audit -KillScope VGOnly | Out-Host
  } catch {
    Write-Host ("WARN: GUARD_FAILED: {0}" -f $_.Exception.Message)
    throw
  }
  if(Test-Path -LiteralPath $pl -PathType Leaf){
    Write-Host ("WARN: PANIC_LOCK_SET_BY_GUARD={0}" -f $pl)
    throw "PANIC_LOCK_SET"
  }
} else {
  Write-Host ("WARN: GUARD_MISSING={0}" -f $guard)
}
# END_VG_GUARD_PRECHECK_V1


$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Ts(){ (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffffffK") }
function Ok([string]$m){ Write-Host ("OK: {0}" -f $m) -ForegroundColor Green }
function Warn([string]$m){ Write-Host ("WARN: {0}" -f $m) -ForegroundColor Yellow }
function Fail([string]$m){ throw $m }

function _TailText([string]$path,[int]$n){
  try{
    if(Test-Path -LiteralPath $path -PathType Leaf){
      return [string]((Get-Content -LiteralPath $path -Tail $n -EA SilentlyContinue | Out-String))
    }
  }catch{}
  return ""
}

function Find-VGWatchdogProc {
  [CmdletBinding()]
  param([Parameter(Mandatory=$true)][string]$WatchdogScriptPath)

  try{
    $needle = [regex]::Escape($WatchdogScriptPath)
    $procs = Get-CimInstance Win32_Process -Filter "Name='pwsh.exe'" -EA SilentlyContinue |
      Where-Object { ([string]$_.CommandLine) -match $needle } |
      Sort-Object CreationDate -Descending
    return @($procs)
  }catch{
    return @()
  }
}

# --- paths
$Pwsh     = Join-Path $env:ProgramFiles "PowerShell\7\pwsh.exe"
$Watchdog = Join-Path $Root "watchdog\watchdog_agentB_logger.ps1"
$PidFile  = Join-Path $Root "runtime\agent.pid"
$LogDir   = Join-Path $Root "logs\agent"

if(!(Test-Path -LiteralPath $Root -PathType Container)){ Fail ("MISSING_ROOT={0}" -f $Root) }
if(!(Test-Path -LiteralPath $Pwsh -PathType Leaf)){ Fail ("MISSING_PWSH={0}" -f $Pwsh) }
if(!(Test-Path -LiteralPath $Watchdog -PathType Leaf)){ Fail ("MISSING_WATCHDOG={0}" -f $Watchdog) }

New-Item -ItemType Directory -Path (Join-Path $Root "runtime") -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

# --- 1) idempotent pre-check: already running?
$existing = @(Find-VGWatchdogProc -WatchdogScriptPath $Watchdog)
if($existing.Count -gt 0){
  $pid0 = [int]$existing[0].ProcessId
  try{
    $p0 = Get-Process -Id $pid0 -EA Stop
    [string]$pid0 | Set-Content -LiteralPath $PidFile -Encoding ASCII -NoNewline -Force
    Ok ("WATCHDOG_ALREADY_RUNNING pid={0} start={1}" -f $pid0,$p0.StartTime)
    return
  }catch{
    Warn ("WATCHDOG_FOUND_BUT_GETPROCESS_FAIL pid={0} err={1}" -f $pid0,$_.Exception.Message)
    # fallthrough -> attempt start
  }
}

# --- 2) start watchdog
$outLog = Join-Path $LogDir ("watchdog_launch_{0}.out.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
$errLog = Join-Path $LogDir ("watchdog_launch_{0}.err.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

Ok ("STARTING_WATCHDOG via={0}" -f $Pwsh)

$proc = Start-Process -FilePath $Pwsh -ArgumentList @(
  "-NoProfile","-ExecutionPolicy","Bypass",
  "-File", $Watchdog
) -PassThru -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog

Start-Sleep -Milliseconds 800

# If process is still alive -> OK
try{
  $pAlive = Get-Process -Id $proc.Id -EA Stop
  [string]$proc.Id | Set-Content -LiteralPath $PidFile -Encoding ASCII -NoNewline -Force
  Ok ("WATCHDOG_STARTED pid={0} name={1}" -f $proc.Id,$pAlive.ProcessName)
  return
}catch{
  Warn ("WATCHDOG_DIED pid={0}" -f $proc.Id)
}

# --- 3) if died: check logs for SINGLETON and bind
$outTail = _TailText -path $outLog -n 200
$errTail = _TailText -path $errLog -n 200
$tailAll = [string]($outTail + "`n" + $errTail)

if($tailAll -match '(?im)SINGLETON|Another instance'){
  Warn "WATCHDOG_SINGLETON_DETECTED -> treating as OK (already running)"
  $hits2 = @(Find-VGWatchdogProc -WatchdogScriptPath $Watchdog)
  if($hits2.Count -gt 0){
    $pid1 = [int]$hits2[0].ProcessId
    try{
      $p1 = Get-Process -Id $pid1 -EA Stop
      [string]$pid1 | Set-Content -LiteralPath $PidFile -Encoding ASCII -NoNewline -Force
      Ok ("WATCHDOG_ALREADY_RUNNING pid={0} start={1}" -f $pid1,$p1.StartTime)
      return
    }catch{
      Warn ("WATCHDOG_SINGLETON_FOUND_BUT_GETPROCESS_FAIL pid={0} err={1}" -f $pid1,$_.Exception.Message)
    }
  }else{
    Warn "WATCHDOG_SINGLETON_BUT_NO_EXISTING_PROC_FOUND"
  }
}

# --- 4) real failure
Warn "---- STDOUT TAIL ----"
if($outTail){ $outTail.TrimEnd() | Write-Host } else { Warn "(empty)" }
Warn "---- STDERR TAIL ----"
if($errTail){ $errTail.TrimEnd() | Write-Host } else { Warn "(empty)" }
  # --- VG_SINGLETON_OK_V4b (SINGLETON => OK; else FAIL)
  try{
    $t = New-Object System.Collections.Generic.List[string]
    function __Tail([string]$p,[int]$n){
      if([string]::IsNullOrWhiteSpace($p)){ return }
      if(Test-Path -LiteralPath $p -PathType Leaf){
        $t.AddRange([string[]](Get-Content -LiteralPath $p -Tail $n -EA SilentlyContinue))
      }
    }

    # Prefer local outLog/errLog if defined
    $haveOut=$false; $haveErr=$false
    try{ if(Get-Variable -Name outLog -Scope 0 -EA SilentlyContinue){ $haveOut=$true } }catch{}
    try{ if(Get-Variable -Name errLog -Scope 0 -EA SilentlyContinue){ $haveErr=$true } }catch{}
    if($haveOut){ __Tail ([string]$outLog) 120 }
    if($haveErr){ __Tail ([string]$errLog) 120 }

    # Fallback newest watchdog_launch logs
    if($t.Count -eq 0){
      $logDir = Join-Path $Root "logs\agent"
      if(Test-Path -LiteralPath $logDir -PathType Container){
        $o = Get-ChildItem -LiteralPath $logDir -File -Filter "watchdog_launch_*.out.log" -EA SilentlyContinue |
             Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $e = Get-ChildItem -LiteralPath $logDir -File -Filter "watchdog_launch_*.err.log" -EA SilentlyContinue |
             Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if($o){ __Tail ([string]$o.FullName) 160 }
        if($e){ __Tail ([string]$e.FullName) 160 }
      }
    }

    $txt = [string]($t -join "`n")
    if($txt -match '(?i)\[WATCHDOG\]\[SINGLETON\]|Another instance is running'){
      Ok 'WATCHDOG_ALREADY_RUNNING_SINGLETON_OK'
      exit 0
    }
  }catch{ }

  Fail "WATCHDOG_START_FAIL"
  # --- end VG_SINGLETON_OK_V4b