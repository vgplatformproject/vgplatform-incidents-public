# =========================
# vg_all.ps1 (v1)
# =========================
# KONTEKST:
# - CORE orchestrator: Start/Stop/Restart/Status/Health za VG.
# - Uporablja obstoječe start/stop skripte, ne duplira logike.
#
# VSEBINA:
# - -Status  : refresh health (optional) + print summary
# - -Health  : samo VG_HealthReport_v1.ps1
# - -Start   : Start agent + start dashboard + wait-for-ready
# - -Stop    : Stop dashboard + stop agent + wait-for-stop
# - -Restart : Stop -> Start
#
# OPS NOTE:
# - Ne briše nič.
# - Vse piše log v D:\VGPlatform\logs\ops\
# - Robustno: timeouts, pid checks, port checks.

[CmdletBinding(DefaultParameterSetName="Status")]
param(
  [Parameter(ParameterSetName="Status")] [switch]$Status,
  [Parameter(ParameterSetName="Health")] [switch]$Health,
  [Parameter(ParameterSetName="Start")]  [switch]$Start,
  [Parameter(ParameterSetName="Stop")]   [switch]$Stop,
  [Parameter(ParameterSetName="Restart")][switch]$Restart,

  [string]$VGRoot = "D:\VGPlatform",

  # Wait settings
  [int]$StartTimeoutSec = 25,
  [int]$StopTimeoutSec  = 20,
  [int]$PollMs = 500,

  # Ports
  [int[]]$DashPorts = @(8501,8502)
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Info($m){ Write-Host ("[INFO] " + $m) -ForegroundColor Cyan }
function Ok($m){ Write-Host ("[OK]   " + $m) -ForegroundColor Green }
function Warn($m){ Write-Host ("[WARN] " + $m) -ForegroundColor Yellow }
function Fail($m){ throw ("[FAIL] " + $m) }

function Need-Dir([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Container)){ Fail "MISSING_DIR=$p" }
}
function Need-File([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Leaf)){ Fail "MISSING_FILE=$p" }
}

function Try-ReadText([string]$p){
  try { return (Get-Content -LiteralPath $p -Raw -EA Stop).Trim() } catch { return $null }
}
function Parse-Int([string]$s){
  if([string]::IsNullOrWhiteSpace($s)){ return $null }
  $n=$null
  if([int]::TryParse($s.Trim(),[ref]$n)){ return $n }
  return $null
}
function Proc-Exists([int]$procId){
  if(!$procId){ return $false }
  try { $null=Get-Process -Id $procId -EA Stop; return $true } catch { return $false }
}
function Port-ListenPid([int]$port){
  try {
    $c = Get-NetTCPConnection -State Listen -LocalPort $port -EA SilentlyContinue | Select-Object -First 1
    if(!$c){ return $null }
    return [int]$c.OwningProcess
  } catch { return $null }
}
function Wait-Until([scriptblock]$cond, [int]$timeoutSec, [int]$pollMs){
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while($sw.Elapsed.TotalSeconds -lt $timeoutSec){
    try {
      if(& $cond){ return $true }
    } catch { }
    Start-Sleep -Milliseconds $pollMs
  }
  return $false
}
function Invoke-PSWithTimeout([string]$File, [string[]]$Args, [int]$TimeoutSec, [string]$LogPrefix){
  # Runs child pwsh detached, waits bounded time, avoids “hang”
  $pwsh = (Get-Command pwsh -EA Stop).Source
  $argList = @("-NoProfile","-File",$File) + $Args
  $p = Start-Process -FilePath $pwsh -ArgumentList $argList -PassThru -WindowStyle Hidden
  $ok = $p.WaitForExit($TimeoutSec * 1000)
  if(-not $ok){
    try { Stop-Process -Id $p.Id -Force -EA SilentlyContinue } catch {}
    throw ("TIMEOUT: {0} file={1} pid={2}" -f $LogPrefix, $File, $p.Id)
  }
  return $p.ExitCode
}

function Heartbeat-Ready([string]$hbPath, [int]$MaxAgeSec){
  if(!(Test-Path -LiteralPath $hbPath -PathType Leaf)){ return $false }
  try {
    $age = (Get-Date) - (Get-Item -LiteralPath $hbPath).LastWriteTime
    return ($age.TotalSeconds -le $MaxAgeSec)
  } catch { return $false }
}

# --- Paths
Need-Dir $VGRoot
$runtime = Join-Path $VGRoot "runtime"
$logsOps = Join-Path $VGRoot "logs\ops"
$opsDir  = Join-Path $VGRoot "core\ops"
$orchDir = Join-Path $VGRoot "core\orchestrator"
Need-Dir $runtime
New-Item -ItemType Directory -Path $logsOps -Force | Out-Null

$healthPS = Join-Path $opsDir "VG_HealthReport_v1.ps1"
Need-File $healthPS

$startAgent = Join-Path $orchDir "start_agent.ps1"
$stopAgent  = Join-Path $orchDir "stop_agent.ps1"
Need-File $startAgent
Need-File $stopAgent

# dashboard start autodetect (prefer the 8501 wrapper if present)
$dashStartCandidates = @(
  (Join-Path $VGRoot "core\dashboard\start_dashboard_8501.ps1"),
  (Join-Path $VGRoot "core\dashboard\start_dashboard.ps1"),
  (Join-Path $VGRoot "core\dashboard\start_dashboard.py")
) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }

if($dashStartCandidates.Count -eq 0){
  Warn "No dashboard start script found in core\dashboard (expected start_dashboard_8501.ps1 or start_dashboard.ps1 or start_dashboard.py)."
}

$dashPidPath  = Join-Path $runtime "dashboard.pid"
$dashPortPath = Join-Path $runtime "dashboard.port"
$agentPidPath = Join-Path $runtime "agent.pid"
$statusJson   = Join-Path $runtime "status.json"

$log = Join-Path $logsOps ("vg_all_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function LogLine([string]$m){
  $line = ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m)
  Add-Content -LiteralPath $log -Value $line -Encoding UTF8
}

Info "LOG=$log"
LogLine "START vg_all.ps1"

function Run-Health {
  Info "Running HealthReport..."
  LogLine "RUN health: $healthPS"
  Invoke-PSWithTimeout -File $healthPS -Args @() -TimeoutSec 30 -LogPrefix "HealthReport" | Out-Null
}

function Print-Summary {
  if(!(Test-Path -LiteralPath $statusJson -PathType Leaf)){
    Warn "status.json missing. Run -Health first."
    return
  }
  $top = Get-Content -LiteralPath $statusJson -TotalCount 60
  $top | ForEach-Object { $_ }
}

function Start-Dashboard {
  if($dashStartCandidates.Count -eq 0){ Fail "DASH_START_NOT_FOUND" }
  $p = $dashStartCandidates[0]
  Info ("Starting dashboard (detached) via: {0}" -f $p)
  LogLine ("START_DASH(detached) via {0}" -f $p)

  if($p.ToLower().EndsWith(".py")){
    # python detached
    $py = (Get-Command python -EA Stop).Source
    Start-Process -FilePath $py -ArgumentList @("`"$p`"") -WorkingDirectory (Split-Path $p) | Out-Null
    return
  }

  # ps1 detached (IMPORTANT: do NOT block on pipeline)
  $pwsh = (Get-Command pwsh -EA Stop).Source
  Start-Process -FilePath $pwsh -ArgumentList @("-NoProfile","-File","`"$p`"") -WorkingDirectory (Split-Path $p) | Out-Null
}

function Stop-Dashboard {
  # Prefer stopping by PID from pidfile
  $pidTxt = Try-ReadText $dashPidPath
  $dashPid = Parse-Int $pidTxt

  $stopped = $false
  if($dashPid -and (Proc-Exists $dashPid)){
    Info ("Stopping dashboard PID (pidfile) {0}" -f $dashPid)
    LogLine ("STOP_DASH pidfile_pid={0}" -f $dashPid)
    try { Stop-Process -Id $dashPid -Force -EA Stop; $stopped = $true } catch { Warn ("Stop-Process failed: {0}" -f $_.Exception.Message) }
  } else {
    Warn "Dashboard PID from pidfile not found/alive; fallback to port PID."
  }

  # Fallback: stop by listening port owning PID (if any)
  if(-not $stopped){
    foreach($p in $DashPorts){
      $lp = Port-ListenPid $p
      if($lp -and (Proc-Exists $lp)){
        Info ("Stopping dashboard PID (port {0}) {1}" -f $p, $lp)
        LogLine ("STOP_DASH port={0} pid={1}" -f $p, $lp)
        try { Stop-Process -Id $lp -Force -EA Stop } catch { Warn ("Stop-Process failed: {0}" -f $_.Exception.Message) }
      }
    }
  }
}

function Start-Agent {
  Info "Starting agent..."
  LogLine "START_AGENT"
  Invoke-PSWithTimeout -File $startAgent -Args @() -TimeoutSec 25 -LogPrefix "start_agent" | Out-Null
}

function Stop-Agent {
  Info "Stopping agent..."
  LogLine "STOP_AGENT"
  Invoke-PSWithTimeout -File $stopAgent -Args @() -TimeoutSec 25 -LogPrefix "stop_agent" | Out-Null
}

function Dash-Ready {
  # Ready if any port is listening
  foreach($p in $DashPorts){
    $lp = Port-ListenPid $p
    if($lp){ return $true }
  }
  return $false
}

function Agent-Ready {
  $pidTxt = Try-ReadText $agentPidPath
  $procId = Parse-Int $pidTxt
  if($procId -and (Proc-Exists $procId)){ return $true }

  # fallback: heartbeat freshness (agent can be “ready” even if pidfile lags)
  if(Heartbeat-Ready $hbPath 20){ return $true }

  return $false
}

function Dash-Stopped {
  foreach($p in $DashPorts){
    $lp = Port-ListenPid $p
    if($lp){ return $false }
  }
  return $true
}

function Agent-Stopped {
  $pidTxt = Try-ReadText $agentPidPath
  $pid = Parse-Int $pidTxt
  if(!$pid){ return $true } # no pid file = consider stopped
  if(Proc-Exists $pid){ return $false }
  return $true
}

# --- Execute command
if($Health){
  Run-Health
  Print-Summary
  Ok "DONE"
  exit 0
}

if($Status){
  # Soft refresh health, but don't fail if it errors
  try { Run-Health } catch { Warn ("Health failed: {0}" -f $_.Exception.Message) }
  Print-Summary
  Ok "DONE"
  exit 0
}

if($Start){
  # Start agent first, then dashboard
  Start-Agent
  Start-Dashboard

  $okA = Wait-Until { Agent-Ready } $StartTimeoutSec $PollMs
  $okD = Wait-Until { Dash-Ready }  $StartTimeoutSec $PollMs

  Run-Health

  if(-not $okA){ Warn "AGENT_NOT_READY (timeout)" }
  if(-not $okD){ Warn "DASH_NOT_READY (timeout)" }

  if($okA -and $okD){ Ok "START_OK" } else { Warn "START_PARTIAL" }
  exit ($(if($okA -and $okD){0}else{2}))
}

if($Stop){
  Stop-Dashboard
  Stop-Agent

  $okD = Wait-Until { Dash-Stopped }  $StopTimeoutSec $PollMs
  $okA = Wait-Until { Agent-Stopped } $StopTimeoutSec $PollMs

  Run-Health

  if($okD -and $okA){ Ok "STOP_OK" } else { Warn "STOP_PARTIAL" }
  exit ($(if($okD -and $okA){0}else{2}))
}

if($Restart){
  & $PSCommandPath -Stop  -VGRoot $VGRoot -StopTimeoutSec $StopTimeoutSec -PollMs $PollMs | Out-Null
  Start-Sleep -Seconds 1
  & $PSCommandPath -Start -VGRoot $VGRoot -StartTimeoutSec $StartTimeoutSec -PollMs $PollMs | Out-Null
  Ok "RESTART_DONE"
  exit 0
}

Warn "No action selected."
exit 1


