# =========================
# start_dashboard_8501.ps1 (stable v2)
# =========================
# KONTEKST:
# - Start Streamlit dashboard na 127.0.0.1:8501.
# - Po uspešnem LISTEN vedno sinhronizira runtime\dashboard.pid na LISTEN owning PID (python),
#   da Health/Stop ne uporabljata stale PID.
#
# VSEBINA:
# - Start detached python -m streamlit run start_dashboard.py ...
# - Wait-for-port
# - Write runtime\dashboard.pid + runtime\dashboard.port
# - Log v logs\ops\

[CmdletBinding()]
param(

  [string]$VGRoot = "D:\VGPlatform",
  [int]$Port = 8501,
  [int]$TimeoutSec = 25,

  [Parameter()]
  [string]$Address = "127.0.0.1"
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function TS(){ (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") }
function Info($m){ Write-Host ("[{0}][INFO] {1}" -f (TS),$m) -ForegroundColor Cyan }
function Ok($m){ Write-Host ("[{0}][OK]   {1}" -f (TS),$m) -ForegroundColor Green }
function Warn($m){ Write-Host ("[{0}][WARN] {1}" -f (TS),$m) -ForegroundColor Yellow }
function Die($m){ throw ("[{0}][FAIL] {1}" -f (TS),$m) }

function NeedDir([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Container)){ Die "MISSING_DIR=$p" }
}
function NeedFile([string]$p){
  if(!(Test-Path -LiteralPath $p -PathType Leaf)){ Die "MISSING_FILE=$p" }
}

function Get-ListenPid([int]$p){
  try{
    $c = Get-NetTCPConnection -State Listen -LocalPort $p -EA SilentlyContinue | Select-Object -First 1
    if(!$c){ return $null }
    return [int]$c.OwningProcess
  } catch { return $null }
}

NeedDir $VGRoot
$dashPy   = Join-Path $VGRoot "core\dashboard\start_dashboard.py"
NeedFile $dashPy

$runtime  = Join-Path $VGRoot "runtime"
NeedDir $runtime

$pidPath  = Join-Path $runtime "dashboard.pid"
$portPath = Join-Path $runtime "dashboard.port"

$opsLogDir = Join-Path $VGRoot "logs\ops"
New-Item -ItemType Directory -Path $opsLogDir -Force | Out-Null
$log = Join-Path $opsLogDir ("dashboard_start_8501_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function LogLine([string]$m){
  Add-Content -LiteralPath $log -Value ("[{0}] {1}" -f (TS),$m) -Encoding UTF8
}

Info "LOG=$log"
LogLine "START start_dashboard_8501.ps1"

# If already listening, just sync PID file and exit OK
$already = Get-ListenPid $Port
if($already){
  Warn "Already listening on 127.0.0.1:${Port} pid=${already} -> sync pidfile and exit"
  Set-Content -LiteralPath $pidPath -Value ($already.ToString()) -Encoding UTF8 -NoNewline -Force
  Set-Content -LiteralPath $portPath -Value ($Port.ToString()) -Encoding UTF8 -NoNewline -Force
  LogLine ("SYNC_EXISTING port={0} pid={1}" -f $Port,$already)
  Ok "SYNC_OK"
  exit 0
}

# Start python detached (streamlit)
$python = (Get-Command python -EA Stop).Source
$argList = @(
  "-m","streamlit","run",$dashPy,
  "--server.address","127.0.0.1",
  "--server.port",$Port.ToString(),
  "--server.headless","true"
)

Info ("Starting python detached: {0}" -f $python)
LogLine ("START python={0} args={1}" -f $python, ($argList -join " "))

$pyProc = $null
try{
  $pyProc = Start-Process -FilePath $python -ArgumentList $argList -WorkingDirectory (Split-Path $dashPy) -PassThru -WindowStyle Hidden
} catch {
  LogLine ("START_FAILED " + $_.Exception.Message)
  Die ("START_FAILED: " + $_.Exception.Message)
}

Info ("PY_STARTED pid={0}" -f $pyProc.Id)
LogLine ("PY_STARTED pid={0}" -f $pyProc.Id)

# Wait for LISTEN, then sync pidfile to LISTEN owning PID
$ok = $false
$listenPid = $null
for($i=0; $i -lt $TimeoutSec; $i++){
  Start-Sleep -Seconds 1
  $listenPid = Get-ListenPid $Port
  if($listenPid){
    $ok = $true
    break
  }
}

if(-not $ok){
  LogLine ("PORT_NOT_LISTENING port={0} started_py_pid={1}" -f $Port, $pyProc.Id)
  Die ("PORT_NOT_LISTENING: port=${Port} started_py_pid=$($pyProc.Id)")
}

# Authoritative PID: owning process of the LISTEN socket
Set-Content -LiteralPath $pidPath -Value ($listenPid.ToString()) -Encoding UTF8 -NoNewline -Force
Set-Content -LiteralPath $portPath -Value ($Port.ToString()) -Encoding UTF8 -NoNewline -Force

LogLine ("OK_LISTENING 127.0.0.1:{0} pid={1} py_started_pid={2}" -f $Port,$listenPid,$pyProc.Id)
Ok ("OK_LISTENING 127.0.0.1:{0} pid={1}" -f $Port,$listenPid)
Ok ("WROTE pidfile={0} pid={1}" -f $pidPath,$listenPid)
exit 0
