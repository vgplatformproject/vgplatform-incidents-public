[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$JsonPath,
  [Parameter()][string]$OutPath = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Ok([string]$m){ Write-Host ("OK: {0}" -f $m) }
function Warn([string]$m){ Write-Host ("WARN: {0}" -f $m) }
function Fail([string]$m){ throw $m }

function EnsureDir([string]$p){
  if([string]::IsNullOrWhiteSpace($p)){ return }
  if(!(Test-Path -LiteralPath $p -PathType Container)){
    New-Item -ItemType Directory -Path $p -Force | Out-Null
  }
}

function WriteTextAtomic([string]$path, [string]$text){
  $d = Split-Path -Parent $path
  EnsureDir $d
  $tmp = $path + ".tmp"
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($tmp, $text, $utf8NoBom)
  Move-Item -LiteralPath $tmp -Destination $path -Force
}

function ToHumanBytes([long]$b){
  if($b -lt 1024){ return ("{0} B" -f $b) }
  $kb = 1024.0
  $mb = $kb*1024
  $gb = $mb*1024
  $tb = $gb*1024
  if($b -lt $mb){ return ("{0:N2} KB" -f ($b/$kb)) }
  if($b -lt $gb){ return ("{0:N2} MB" -f ($b/$mb)) }
  if($b -lt $tb){ return ("{0:N2} GB" -f ($b/$gb)) }
  return ("{0:N2} TB" -f ($b/$tb))
}

if(!(Test-Path -LiteralPath $JsonPath -PathType Leaf)){ Fail "MISSING_JSON=$JsonPath" }

$raw = Get-Content -LiteralPath $JsonPath -Raw -Encoding UTF8
try { $rep = $raw | ConvertFrom-Json } catch { Fail ("JSON_PARSE_FAIL: " + $_.Exception.Message) }

if([string]::IsNullOrWhiteSpace($OutPath)){
  $OutPath = [System.IO.Path]::ChangeExtension($JsonPath, ".md")
}

$md = New-Object System.Collections.Generic.List[string]

# Header
[void]$md.Add("# VG Front Audit Report")
[void]$md.Add("")
if($rep.run){
  [void]$md.Add(("- Run: `{0}`" -f [string]$rep.run.id))
  [void]$md.Add(("- Time: `{0}`" -f [string]$rep.run.ts))
  [void]$md.Add(("- Root: `{0}`" -f [string]$rep.run.root))
}
[void]$md.Add("")

# Signals
[void]$md.Add("## Signals")
[void]$md.Add("")
$signals = @()
try { $signals = @($rep.signals) } catch { $signals = @() }
if($signals.Count -eq 0){
  [void]$md.Add("- (none)")
} else {
  foreach($s in $signals){ [void]$md.Add(("- " + [string]$s)) }
}
[void]$md.Add("")

# Queue
[void]$md.Add("## Queue")
[void]$md.Add("")
$q = $null
try { $q = $rep.fronts.OPS_QUEUE.queue_counts } catch { $q = $null }
if($q){
  [void]$md.Add(("- pending: **{0}**" -f [string]$q.pending))
  [void]$md.Add(("- working: **{0}**" -f [string]$q.working))
  [void]$md.Add(("- done: **{0}**" -f [string]$q.done))
  [void]$md.Add(("- failed: **{0}**" -f [string]$q.failed))
} else {
  [void]$md.Add("- (no queue data)")
}
[void]$md.Add("")

# Scheduled tasks
[void]$md.Add("## Scheduled Tasks")
[void]$md.Add("")
[void]$md.Add("| Name | Exists | State | LastRun | LastResult | NextRun | Missed |")
[void]$md.Add("|---|---:|---|---|---|---|---:|")
$tasks = @()
try { $tasks = @($rep.fronts.SCHEDULED_TASKS.tasks) } catch { $tasks=@() }
foreach($t in $tasks){
  [void]$md.Add(("| {0} | {1} | {2} | {3} | {4} | {5} | {6} |" -f
    [string]$t.name,
    [string]$t.exists,
    [string]$t.state,
    [string]$t.lastRun,
    [string]$t.lastResult,
    [string]$t.nextRun,
    [string]$t.missed
  ))
}
[void]$md.Add("")

# Top dirs
[void]$md.Add("## Top Directories (size)")
[void]$md.Add("")
[void]$md.Add("| Path | Size |")
[void]$md.Add("|---|---:|")
$topDirs = @()
try { $topDirs = @($rep.fronts.LOGS_PERF.top_dirs) } catch { $topDirs=@() }
foreach($d in $topDirs){
  $sz = 0L
  try { $sz = [long]$d.size } catch { $sz = 0L }
  [void]$md.Add(("| `{0}` | {1} |" -f [string]$d.path, (ToHumanBytes $sz)))
}
[void]$md.Add("")

# Top files
[void]$md.Add("## Top Files (size)")
[void]$md.Add("")
[void]$md.Add("| Path | Size | Modified |")
[void]$md.Add("|---|---:|---|")
$topFiles = @()
try { $topFiles = @($rep.fronts.LOGS_PERF.top_files) } catch { $topFiles=@() }
foreach($f in $topFiles){
  $sz = 0L
  try { $sz = [long]$f.size } catch { $sz = 0L }
  [void]$md.Add(("| `{0}` | {1} | {2} |" -f [string]$f.path, (ToHumanBytes $sz), [string]$f.mtime))
}
[void]$md.Add("")

# Write
WriteTextAtomic -path $OutPath -text ($md -join [Environment]::NewLine)
Ok ("WRITE_OK={0}" -f $OutPath)
Ok "DONE"