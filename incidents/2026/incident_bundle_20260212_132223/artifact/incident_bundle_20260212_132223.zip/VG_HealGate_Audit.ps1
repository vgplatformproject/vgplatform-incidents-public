param(
  [Parameter(Mandatory=$false)][string]$Root="D:\VGPlatform"
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function J([string]$s){ if($null -eq $s){""} else {[string]$s} }
function NowIso(){ (Get-Date).ToString("o") }

function Add-Finding($list,[string]$level,[string]$code,[string]$file,[string]$note){
  $list.Add([pscustomobject]@{
    ts=NowIso(); level=$level; code=$code; file=$file; note=$note
  }) | Out-Null
}

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = Join-Path $Root ("runtime\_scratch\reports\healgate_{0}" -f $ts)
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

$findings = New-Object System.Collections.Generic.List[object]

# --- 1) Find likely API scripts (simple heuristic)
$apiDir = Join-Path $Root "core\ops\api"
$apiFiles = @()
if(Test-Path -LiteralPath $apiDir){
  $apiFiles = Get-ChildItem -LiteralPath $apiDir -Filter "*.ps1" -File -EA SilentlyContinue
}

if(@($apiFiles).Count -eq 0){
  Add-Finding $findings "WARN" "NO_API_FILES" $apiDir "No *.ps1 found in core\ops\api"
} else {
  foreach($f in $apiFiles){
    $txt = Get-Content -LiteralPath $f.FullName -Raw -EA SilentlyContinue
    $hasTimeout = ($txt -match '(?i)-TimeoutSec\b' -or $txt -match '(?i)TimeoutSec\s*=')
    $hasCap     = ($txt -match '(?i)-MaxBodyChars\b' -or $txt -match '(?i)MaxBodyChars\s*=' -or $txt -match '(?i)PROMPT_TOO_LARGE')
    $hasDecision= ($txt -match '(?i)Emit-Decision\b' -or $txt -match '(?i)DENY|DEFER')
    $throwsHard = ($txt -match '(?m)^\s*throw\s+' -or $txt -match '(?i)Write-Error')

    if(-not $hasTimeout){ Add-Finding $findings "FAIL" "API_NO_TIMEOUT" $f.FullName "Missing -TimeoutSec (bounded call required)" }
    if(-not $hasCap){     Add-Finding $findings "FAIL" "API_NO_CAP"     $f.FullName "Missing body/prompt cap (MaxBodyChars/PROMPT_TOO_LARGE handling)" }
    if(-not $hasDecision){Add-Finding $findings "WARN" "API_NO_DECISION" $f.FullName "No Emit-Decision/DEFER/DENY pattern detected (might still be ok)" }
    if($throwsHard -and -not $hasDecision){
      Add-Finding $findings "WARN" "API_MAY_THROW" $f.FullName "Throw/Write-Error present without decision pattern; could bubble up"
    }
  }
}

# --- 2) Scheduled Tasks: verify VGOpenAIHealth points to expected script and is bounded-ish
$tasks = Get-ScheduledTask -EA SilentlyContinue
foreach($t in @($tasks)){
  if($t.TaskName -in @("VGOpenAIHealth","VGQueueTick","VGQueuePS1","VGAgent","VGAgentWatchdog","VGHolmesObserver","VG_PID_Watchdog_2min")){
    $acts=@(); try{ $acts=@($t.Actions) }catch{ $acts=@() }
    foreach($a in @($acts)){
      $p=@($a.PSObject.Properties.Name)
      $exe = if($p -contains 'Execute'){ [string]$a.Execute } else { "" }
      $arg = if($p -contains 'Arguments'){ [string]$a.Arguments } else { "" }
      $line = ($exe + " " + $arg).Trim()

      if($t.TaskName -eq "VGQueueTick"){
        if($line -notmatch '(?i)queue_tick_taskwrap_safe\.ps1'){
          Add-Finding $findings "FAIL" "TASK_QUEUE_TICK_NOT_SAFE" ($t.TaskPath+$t.TaskName) ("VGQueueTick does not use queue_tick_taskwrap_safe.ps1 :: " + $line)
        }
      }

      if($t.TaskName -eq "VGOpenAIHealth"){
        if($line -notmatch '(?i)HealthCheck_Chat4oMini\.ps1'){
          Add-Finding $findings "WARN" "TASK_OPENAIHEALTH_TARGET" ($t.TaskPath+$t.TaskName) ("Unexpected target :: " + $line)
        }
        if($line -notmatch '(?i)-TimeoutSec\b'){
          Add-Finding $findings "FAIL" "TASK_OPENAIHEALTH_NO_TIMEOUT" ($t.TaskPath+$t.TaskName) ("No -TimeoutSec in task arguments :: " + $line)
        }
      }
    }
  }
}

# --- 3) Queue worker config hazard check
$spawn = Join-Path $Root "runtime\_scratch\reports"
$haz = Get-ChildItem -LiteralPath $spawn -Filter "pwsh_spawn_watch_*.log" -File -EA SilentlyContinue |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1

if($null -ne $haz){
  $txt = Get-Content -LiteralPath $haz.FullName -Raw -EA SilentlyContinue
  if($txt -match '(?i)-MaxIdleSec\s+0'){
    Add-Finding $findings "WARN" "QUEUE_MAXIDLE_ZERO_SEEN" $haz.FullName "Spawn log shows -MaxIdleSec 0; ensure lock+bounded run exists"
  }
}

# --- write outputs
$json = Join-Path $outDir "healgate_report.json"
$md   = Join-Path $outDir "healgate_report.md"

$findings | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $json -Encoding UTF8
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("# VG HealGate Audit") | Out-Null
$lines.Add("") | Out-Null
$lines.Add(("- Generated: " + (NowIso()))) | Out-Null
$lines.Add(("- Root: " + $Root)) | Out-Null
$lines.Add("") | Out-Null

$fail = @($findings | Where-Object { $_.level -eq "FAIL" })
$warn = @($findings | Where-Object { $_.level -eq "WARN" })

$lines.Add(("## Summary")) | Out-Null
$lines.Add(("")) | Out-Null
$lines.Add(("- FAIL: " + $fail.Count)) | Out-Null
$lines.Add(("- WARN: " + $warn.Count)) | Out-Null
$lines.Add(("")) | Out-Null

$lines.Add("## Findings") | Out-Null
$lines.Add("") | Out-Null
foreach($f in $findings){
  $lines.Add(("- [{0}] {1} :: {2} :: {3}" -f $f.level,$f.code,$f.file,$f.note)) | Out-Null
}

Set-Content -LiteralPath $md -Encoding UTF8 -Value ($lines -join "`r`n")

Write-Host ("OK: OUTDIR={0}" -f $outDir) -ForegroundColor Green
Write-Host ("OK: JSON={0}" -f $json) -ForegroundColor Green
Write-Host ("OK: MD={0}" -f $md) -ForegroundColor Green

if($fail.Count -gt 0){ exit 2 } else { exit 0 }