Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'

function Ok([string]$m){ Write-Host "OK: $m" }
function Warn([string]$m){ Write-Host "WARN: $m" }
function Fail([string]$m){ throw $m }
function Assert-File([string]$p){ if(!(Test-Path -LiteralPath $p -PathType Leaf)){ Fail "MISSING_FILE=$p" } }
function Sha256File([string]$p){ (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
function ContainsAll([string]$text,[string[]]$needles){
  foreach($n in $needles){ if($text -notmatch [regex]::Escape($n)){ return $false } }
  return $true
}

function Get-BoundedLines([string]$path,[int]$Head=400,[int]$Tail=400){
  $h = Get-Content -LiteralPath $path -TotalCount $Head -Encoding UTF8
  $t = Get-Content -LiteralPath $path -Tail $Tail -Encoding UTF8
  return ,(@($h + "-----[...snip...]-----" + $t))
}

function Diff-Lines([string[]]$a,[string[]]$b,[int]$Max=200){
  $co = Compare-Object -ReferenceObject $a -DifferenceObject $b -IncludeEqual:$false
  $out = New-Object System.Collections.Generic.List[string]
  $n=0
  foreach($x in $co){
    $n++; if($n -gt $Max){ break }
    $side=$x.SideIndicator
    $line=[string]$x.InputObject
    if($side -eq '<='){ $out.Add(("- {0}" -f $line)) }
    elseif($side -eq '=>'){ $out.Add(("+ {0}" -f $line)) }
    else { $out.Add(("? {0}" -f $line)) }
  }
  return ,$out.ToArray()
}

$Root="D:\VGPlatform"
$Base=Join-Path $Root "core\ops\instructions"
$Out =Join-Path $Base "out"

$chatV1=Join-Path $Out "CHAT_instructions.txt"
$apiV1 =Join-Path $Out "API_system_prompt.txt"
$chatV2=Join-Path $Out "CHAT_instructions_v2.txt"
$apiV2 =Join-Path $Out "API_system_prompt_v2.txt"

Assert-File $chatV2
Assert-File $apiV2

$hasV1 = (Test-Path -LiteralPath $chatV1 -PathType Leaf) -and (Test-Path -LiteralPath $apiV1 -PathType Leaf)
if($hasV1){ Ok "V1_PRESENT=1" } else { Warn "V1_MISSING=bounded_diff_only_invariants" }

$txtChat2 = Get-Content -LiteralPath $chatV2 -Raw -Encoding UTF8
$txtApi2  = Get-Content -LiteralPath $apiV2  -Raw -Encoding UTF8

$requiredTags=@("[VG_CORE]","[VG_OPS]","[VG_STYLE]","[VG_API_EXEC]","[VG_PROFILE]")
foreach($t in $requiredTags){
  if($txtChat2 -notmatch [regex]::Escape($t)){ Fail "CHAT_V2_MISSING_TAG=$t" }
  if($txtApi2  -notmatch [regex]::Escape($t)){ Fail "API_V2_MISSING_TAG=$t" }
}
Ok "TAGS_OK=1"

$coreNeedles=@("Konzervativno","nič mimo CORE","Audit","backup -> diff -> parse-check -> bounded smoke","JSON se nikoli ne lepi direktno")
if(-not (ContainsAll $txtChat2 $coreNeedles)){ Fail "CHAT_V2_CORE_INVARIANTS_FAIL" }
if(-not (ContainsAll $txtApi2  $coreNeedles)){ Fail "API_V2_CORE_INVARIANTS_FAIL" }
Ok "CORE_INVARIANTS_OK=1"

$rep = New-Object System.Collections.Generic.List[string]
$rep.Add("# VG InstructionPack diff gate (v2b, bounded)")
$rep.Add("")
$rep.Add(("Generated: {0}" -f (Get-Date).ToString("o")))
$rep.Add("")

if($hasV1){
  $rep.Add("## Diff: CHAT v1 -> v2 (bounded head/tail, top 200)")
  $rep.Add("```diff")
  $a = Get-BoundedLines $chatV1 400 400
  $b = Get-BoundedLines $chatV2 400 400
  foreach($ln in (Diff-Lines $a $b 200)){ $rep.Add($ln) }
  $rep.Add("```")
  $rep.Add("")

  $rep.Add("## Diff: API v1 -> v2 (bounded head/tail, top 200)")
  $rep.Add("```diff")
  $c = Get-BoundedLines $apiV1 400 400
  $d = Get-BoundedLines $apiV2 400 400
  foreach($ln in (Diff-Lines $c $d 200)){ $rep.Add($ln) }
  $rep.Add("```")
  $rep.Add("")
}

$release=[ordered]@{
  ts=(Get-Date).ToString("o")
  active=@{ chat=(Split-Path -Leaf $chatV2); api=(Split-Path -Leaf $apiV2) }
  sha256=@{ chat_v2=(Sha256File $chatV2); api_v2=(Sha256File $apiV2) }
  invariants=@{ tags_ok=$true; core_ok=$true; required_tags=$requiredTags; core_needles=$coreNeedles }
}

$rep.Add("## Release marker")
$rep.Add("")
$rep.Add(("Active CHAT: {0}" -f $release.active.chat))
$rep.Add(("Active API : {0}" -f $release.active.api))
$rep.Add(("SHA256 CHAT v2: {0}" -f $release.sha256.chat_v2))
$rep.Add(("SHA256 API  v2: {0}" -f $release.sha256.api_v2))
$rep.Add("")

$diffFp=Join-Path $Out "diff_report.md"
($rep -join "`r`n") | Set-Content -LiteralPath $diffFp -Encoding UTF8
Ok "WRITE_OK=$diffFp"

$relFp=Join-Path $Out "release_active.json"
($release | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $relFp -Encoding UTF8
Ok "WRITE_OK=$relFp"

try{ $null = Get-Content -LiteralPath $relFp -Raw -Encoding UTF8 | ConvertFrom-Json; Ok "JSON_PARSE_OK=$relFp" }catch{ Fail ("JSON_PARSE_FAIL=$relFp err=" + $_.Exception.Message) }

Ok "DONE=DIFF_GATE_OK"
Ok "NEXT: open out\diff_report.md; use out\release_active.json"
