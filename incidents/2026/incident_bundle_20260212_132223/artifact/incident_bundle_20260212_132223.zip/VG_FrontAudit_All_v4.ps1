[CmdletBinding()]
param(
  [Parameter()][string]$Root = "D:\VGPlatform",
  [Parameter()][switch]$NoRecurseHeavy
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

trap {
  Write-Host "=== TRAP ==="
  Write-Host ("MSG=" + $PSItem.Exception.Message)
  Write-Host ("TYPE=" + $PSItem.Exception.GetType().FullName)
  Write-Host "--- ScriptStackTrace ---"
  Write-Host $PSItem.ScriptStackTrace
  throw
}
function Ok([string]$m){ Write-Host ("OK: {0}" -f $m) }
function Warn([string]$m){ Write-Host ("WARN: {0}" -f $m) }
function Fail([string]$m){ throw $m }

function EnsureDir([string]$p){
  if([string]::IsNullOrWhiteSpace($p)){ return }
  
function CountFilesSafe([string]$dir){
  try{
    if([string]::IsNullOrWhiteSpace($dir)){ return 0 }
    if(Test-Path -LiteralPath $dir -PathType Container){
      return @((Get-ChildItem -LiteralPath $dir -File -EA SilentlyContinue)).Count
    }
  }catch{}
  return 0
}
if(!(Test-Path -LiteralPath $p -PathType Container)){
    New-Item -ItemType Directory -Path $p -Force | Out-Null
  }
}

function ReadJson([string]$p){
  try{ return (Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null }
}

function GetNewestFile([string]$dir,[string]$filter){
  try{
    return (Get-ChildItem -LiteralPath $dir -File -Filter $filter -EA SilentlyContinue |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1)
  } catch { return $null }
}

function PortInfo([int]$port){
  try{ return @(Get-NetTCPConnection -State Listen -LocalPort $port -EA SilentlyContinue) } catch { return @() }
}

function NowIso(){ return (Get-Date).ToString("s") }

if(!(Test-Path -LiteralPath $Root -PathType Container)){ Fail ("ROOT_NOT_FOUND={0}" -f $Root) }

$reportDir = Join-Path $Root "reports\front_audit"
EnsureDir $reportDir
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$reportJson = Join-Path $reportDir ("front_audit_{0}.json" -f $ts)
$reportMd   = Join-Path $reportDir ("front_audit_{0}.md" -f $ts)

$signals = New-Object System.Collections.Generic.List[object]
function AddSig([string]$front,[string]$level,[string]$code,[object]$data){
  [void]$signals.Add([pscustomobject]@{
    ts    = NowIso
    front = $front
    level = $level
    code  = $code
    data  = $data
  })
}

$paths = @{
  start_agent  = (Join-Path $Root "core\orchestrator\start_agent.ps1")
  stop_agent   = (Join-Path $Root "core\orchestrator\stop_agent.ps1")
  watchdog     = (Join-Path $Root "watchdog\watchdog_agentB_logger.ps1")
  queue_worker = (Join-Path $Root "core\queue\queue_worker.ps1")
  dashboard_py = (Join-Path $Root "core\dashboard\start_dashboard.py")
  pid_file     = (Join-Path $Root "runtime\agent.pid")
  heartbeat    = (Join-Path $Root "runtime\heartbeat.json")
  q_pending    = (Join-Path $Root "queue\pending")
  q_working    = (Join-Path $Root "queue\working")
  q_done       = (Join-Path $Root "queue\done")
  q_failed     = (Join-Path $Root "queue\failed")
  log_dash     = (Join-Path $Root "logs\dashboard")
  log_agent    = (Join-Path $Root "logs\agent")
}

foreach($k in $paths.Keys){
  $p = [string]$paths[$k]
  if(Test-Path -LiteralPath $p){
    AddSig "PRE" "OK" "EXISTS" @{ key=$k; path=$p }
  } else {
    AddSig "PRE" "WARN" "MISSING" @{ key=$k; path=$p }
  }
}

# QUEUE counts (no ternary; StrictMode-safe)
try{
  $pending = 0; $working = 0; $done = 0; $failed = 0
  if(Test-Path -LiteralPath $paths.q_pending -PathType Container){ $pending = @((Get-ChildItem -LiteralPath $paths.q_pending -File -EA SilentlyContinue)).Count }
  if(Test-Path -LiteralPath $paths.q_working -PathType Container){ $working = @((Get-ChildItem -LiteralPath $paths.q_working -File -EA SilentlyContinue)).Count }
  if(Test-Path -LiteralPath $paths.q_done    -PathType Container){ $done    = @((Get-ChildItem -LiteralPath $paths.q_done    -File -EA SilentlyContinue)).Count }
  if(Test-Path -LiteralPath $paths.q_failed  -PathType Container){ $failed  = @((Get-ChildItem -LiteralPath $paths.q_failed  -File -EA SilentlyContinue)).Count }
  AddSig "QUEUE" "OK" "COUNTS" @{ pending=$pending; working=$working; done=$done; failed=$failed }
} catch {
  AddSig "QUEUE" "WARN" "COUNTS_FAIL" @{ err=$_.Exception.Message }
}

# HEARTBEAT age
try{
  if(Test-Path -LiteralPath $paths.heartbeat -PathType Leaf){
    $hb = ReadJson $paths.heartbeat
    if($null -ne $hb -and ($hb.PSObject.Properties.Name -contains "ts")){
      $hbTs = [datetime]::Parse([string]$hb.ts)
      $ageSec = [math]::Round(((Get-Date) - $hbTs).TotalSeconds,0)
      AddSig "HEARTBEAT" "OK" "AGE" @{ ts=[string]$hb.ts; ageSec=$ageSec }
      if($ageSec -gt 120){ AddSig "HEARTBEAT" "WARN" "STALE" @{ ageSec=$ageSec } }
    } else {
      AddSig "HEARTBEAT" "WARN" "NO_TS" @{ path=$paths.heartbeat }
    }
  } else {
    AddSig "HEARTBEAT" "WARN" "NO_FILE" @{ path=$paths.heartbeat }
  }
} catch {
  AddSig "HEARTBEAT" "WARN" "READ_FAIL" @{ err=$_.Exception.Message }
}

# AGENT/WATCHDOG (DO NOT use $pid name)
try{
  $agentPid = $null
  if(Test-Path -LiteralPath $paths.pid_file -PathType Leaf){
    $rawPid = (Get-Content -LiteralPath $paths.pid_file -Raw -EA SilentlyContinue)
    if($null -ne $rawPid){
      $rawPid = $rawPid.Trim()
      if($rawPid -match '^\d+$'){ $agentPid = [int]$rawPid }
    }
    AddSig "AGENT" "OK" "PID_FILE" @{ path=$paths.pid_file; pid=$agentPid }
  } else {
    AddSig "AGENT" "WARN" "NO_PID_FILE" @{ path=$paths.pid_file }
  }

  if($agentPid){
    $proc = Get-Process -Id $agentPid -EA SilentlyContinue
    if($null -ne $proc){
      AddSig "AGENT" "OK" "PID_ALIVE" @{ pid=$agentPid; name=$proc.ProcessName; start=$proc.StartTime }
    } else {
      AddSig "AGENT" "WARN" "PID_NOT_RUNNING" @{ pid=$agentPid }
    }
  }

  if(Test-Path -LiteralPath $paths.log_agent -PathType Container){
    $la1 = GetNewestFile $paths.log_agent "agent_*.log"
    $la2 = GetNewestFile $paths.log_agent "watchdog_*.log"
    if($la1){ AddSig "AGENT" "OK" "NEWEST_AGENT_LOG" @{ path=$la1.FullName; size=$la1.Length; ts=$la1.LastWriteTime } } else { AddSig "AGENT" "WARN" "NO_AGENT_LOG" @{} }
    if($la2){ AddSig "WATCHDOG" "OK" "NEWEST_WATCHDOG_LOG" @{ path=$la2.FullName; size=$la2.Length; ts=$la2.LastWriteTime } } else { AddSig "WATCHDOG" "WARN" "NO_WATCHDOG_LOG" @{} }
  }
} catch {
  AddSig "AGENT" "WARN" "CHECK_FAIL" @{ err=$_.Exception.Message }
}

# DASHBOARD (ports + python procs + newest log)
try{
  $ports = @()
  foreach($pp in @(8501,8502)){
    $c = @(PortInfo $pp)
    if(@($c).Count -gt 0){
      $ports += [pscustomobject]@{
        port  = $pp
        count = @($c).Count
        local = [string]$c[0].LocalAddress
        pid   = [int]$c[0].OwningProcess
      }
    }
  }
  if($ports.Count -gt 0){ AddSig "DASHBOARD" "OK" "PORT_LISTEN" $ports } else { AddSig "DASHBOARD" "WARN" "NO_LISTENER_8501_8502" @{} }

  $pyProcs = @(
    Get-CimInstance Win32_Process -EA SilentlyContinue |
      Where-Object { $_.Name -in @("python.exe","pythonw.exe") } |
      Where-Object { $_.CommandLine -and ($_.CommandLine -like "*streamlit*" -or $_.CommandLine -like "*start_dashboard.py*") } |
      Select-Object -First 5 ProcessId,CreationDate,Name,CommandLine
  )
  if(@($pyProcs).Count -gt 0){ AddSig "DASHBOARD" "OK" "PY_PROCS" @($pyProcs) } else { AddSig "DASHBOARD" "WARN" "NO_STREAMLIT_PROCS" @{} }

  if(Test-Path -LiteralPath $paths.log_dash -PathType Container){
    $ld = GetNewestFile $paths.log_dash "dashboard_*.log"
    if($ld){
      AddSig "DASHBOARD" "OK" "NEWEST_LOG" @{ path=$ld.FullName; size=$ld.Length; ts=$ld.LastWriteTime }
      if($ld.Length -eq 0){ AddSig "DASHBOARD" "WARN" "LOG_EMPTY" @{ path=$ld.FullName } }
    } else {
      AddSig "DASHBOARD" "WARN" "NO_LOGS" @{ dir=$paths.log_dash }
    }
  } else {
    AddSig "DASHBOARD" "WARN" "NO_LOG_DIR" @{ dir=$paths.log_dash }
  }
} catch {
  AddSig "DASHBOARD" "WARN" "CHECK_FAIL" @{ err=$_.Exception.Message }
}

# OPS: VG pwsh procs
try{
  $vgPwsh = @(
    Get-CimInstance Win32_Process -EA SilentlyContinue |
      Where-Object { $_.Name -in @("pwsh.exe","powershell.exe") } |
      Where-Object { $_.CommandLine -and $_.CommandLine -like "*D:\VGPlatform*" } |
      Select-Object ProcessId,CreationDate,Name,CommandLine
  )
  AddSig "OPS" "OK" "VG_PWSH_PROCS" @{ count=@($vgPwsh).Count; procs=$vgPwsh }
} catch {
  AddSig "OPS" "WARN" "VG_PWSH_PROCS_FAIL" @{ err=$_.Exception.Message }
}

# TASKS
try{
  $tasks = @("VGAgent","VGDashboard","VGAgentWatchdog","VGLogsRotate","VGLogsCap")
  foreach($t in $tasks){
    $st = Get-ScheduledTask -TaskName $t -EA SilentlyContinue
    if($null -eq $st){ AddSig "TASKS" "WARN" "TASK_NOT_FOUND" @{ task=$t }; continue }
    $info = Get-ScheduledTaskInfo -TaskName $t -EA SilentlyContinue
    AddSig "TASKS" "OK" "TASK" @{
      task=$t
      state=[string]$st.State
      lastRun=[string]$info.LastRunTime
      lastResult=("0x{0:X}" -f $info.LastTaskResult)
      nextRun=[string]$info.NextRunTime
      missed=[int]$info.NumberOfMissedRuns
    }
  }
} catch {
  AddSig "TASKS" "WARN" "TASKS_FAIL" @{ err=$_.Exception.Message }
}

# WRITE reports
# (safe) convert signals list -> array, and ensure strings are strings
$signalsArr = @()
try{
  if($null -ne $signals){
    if($signals -is [System.Collections.ICollection]){
      try{ $signalsArr = @($signals.ToArray()) } catch { $signalsArr = @($signals) }
    } else {
      $signalsArr = @($signals)
    }
  }
}catch{ $signalsArr = @() }

$payload = [pscustomobject]@{
  generated = [string](NowIso)
  root      = [string]$Root
  signals   = $signalsArr
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($reportJson, ($payload | ConvertTo-Json -Depth 10), $utf8NoBom)

# BEGIN_VG_MD_SAFE_V5
$md = New-Object System.Collections.Generic.List[string]
[void]$md.Add("# VG Front Audit v5")
[void]$md.Add("")
[void]$md.Add(("- generated: " + [string](NowIso)))
[void]$md.Add(("- root: " + [string]$Root))
[void]$md.Add("")
[void]$md.Add("## Signals")
[void]$md.Add("")

# signals list -> array (defensive) then safe-sort by ts as string
$sArr = @()
try{
  if($null -ne $signalsArr){ $sArr = @($signalsArr) }
  elseif($null -ne $signals){ $sArr = @($signals) }
}catch{ $sArr = @() }

# create sortable projection with ts string (avoid binder issues)
$proj = @()
foreach($s in $sArr){
  try{
    $tsStr = ""; try{ $tsStr = [string]$s.ts } catch { $tsStr = "" }
    $front = ""; try{ $front = [string]$s.front } catch { $front = "" }
    $level = ""; try{ $level = [string]$s.level } catch { $level = "" }
    $code  = ""; try{ $code  = [string]$s.code  } catch { $code  = "" }
    $proj += [pscustomobject]@{ ts=$tsStr; front=$front; level=$level; code=$code }
  }catch{}
}

# safe sort (string compare)
$proj2 = @()
try{ $proj2 = @($proj | Sort-Object -Property ts -Descending) }catch{ $proj2 = @($proj) }

foreach($x in $proj2){
  [void]$md.Add(("* **{0}** [{1}/{2}] {3}" -f $x.ts,$x.front,$x.level,$x.code))
}

[System.IO.File]::WriteAllText($reportMd, ($md -join [Environment]::NewLine), $utf8NoBom)
# END_VG_MD_SAFE_V5

Ok ("WRITE_OK={0}" -f $reportJson)
Ok ("WRITE_OK={0}" -f $reportMd)
# BEGIN_VG_SIGNALS_COUNT_SAFE_V1

# BEGIN_VG_TRIM_SECOND_HEADER_V1
# Trimmed duplicate [CmdletBinding()] header + tail content
# END_VG_TRIM_SECOND_HEADER_V1
