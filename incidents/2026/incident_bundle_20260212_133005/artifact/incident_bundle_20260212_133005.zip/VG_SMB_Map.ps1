[CmdletBinding()]
param(
  [Parameter()][string]$ComputerName = $env:COMPUTERNAME,
  [Parameter()][string]$ShareName    = 'VGPlatform$',
  [Parameter()][ValidatePattern('^[A-Z]$')][string]$DriveLetter = 'V'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-LogRoot {
  if(Test-Path -LiteralPath 'D:\' -PathType Container){ return 'D:\VGPlatform\logs\net' }
  return 'C:\VGPlatform\logs\net'
}

function Write-Log {
  param(
    [Parameter(Mandatory=$true)][string]$Message,
    [ValidateSet('INFO','OK','WARN','FAIL')][string]$Level = 'INFO'
  )
  $dir = Get-LogRoot
  try{ New-Item -ItemType Directory -Path $dir -Force | Out-Null } catch {}
  $logPath = Join-Path $dir ("monitor_status_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
  $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1} | {2}" -f (Get-Date), $Level, $Message
  Write-Host $line
  Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

try{
  $unc = "\\{0}\{1}" -f $ComputerName, $ShareName
  $dl  = ($DriveLetter + ':')

  Write-Log ("TCP 445 test -> {0}" -f $ComputerName) 'INFO'
  $tnc = $null
  try{ $tnc = Test-NetConnection -ComputerName $ComputerName -Port 445 -WarningAction SilentlyContinue } catch {}
  if(-not ($tnc -and $tnc.TcpTestSucceeded)){
    Write-Log ("FAIL | TCP 445 NOT reachable on {0}" -f $ComputerName) 'FAIL'
    throw "TCP_445_NOT_REACHABLE"
  }
  Write-Log ("OK | TCP 445 reachable on {0} (Ping={1})" -f $ComputerName, $tnc.PingSucceeded) 'OK'

  if(-not (Test-Path -LiteralPath $unc)){
    Write-Log ("FAIL | UNC NOT reachable: {0}" -f $unc) 'FAIL'
    throw "UNC_NOT_REACHABLE"
  }
  Write-Log ("OK | UNC reachable: {0}" -f $unc) 'OK'

  try{ Remove-PSDrive -Name $DriveLetter -Force -ErrorAction SilentlyContinue } catch {}
  & cmd /c ("net use {0} /delete /y" -f $dl) | Out-Null

  New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root $unc -Persist | Out-Null
  Write-Log ("OK | Mapped: {0} -> {1}" -f $dl, $unc) 'OK'

  $testFile = Join-Path $dl '__vg_core_write_test.txt'
  'test' | Out-File -LiteralPath $testFile -Encoding UTF8 -ErrorAction Stop
  if(Test-Path -LiteralPath $testFile){
    Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue
    Write-Log 'OK | UNC write/delete OK' 'OK'
  } else {
    Write-Log ("WARN | Could not write to {0}" -f $dl) 'WARN'
  }

  exit 0
}
catch{
  Write-Log ("Error: " + $_.Exception.Message) 'FAIL'
  exit 2
}