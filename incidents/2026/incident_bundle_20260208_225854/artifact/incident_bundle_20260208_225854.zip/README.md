# Incident: dashboard_port_fail

**Timestamp:** 2026-02-04_231641

**Reason:** PORT_NOT_LISTENING

**TriggerCmd:**
~~~
Start-ScheduledTask -TaskName "VGDashboard"
~~~

## Contents
- meta/: meta.json, system.txt
- state/: runtime state snapshots, ports
- logs/: log tails
- repro/: repro.ps1 skeleton
- extra/: optional included paths

## Next steps (Human gate)
1) Review for sensitive info (paths, usernames, machine name).
2) If publishing: sanitize + anonymize.
3) Run repro/repro.ps1 and confirm.
4) Add fix notes + patch/diff if available.

